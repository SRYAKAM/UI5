sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator, MessageBox) {
	"use strict";

	return BaseController.extend("position_maintenance.PositionMaintenance.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			jQuery(".sapUShellFullHeight").addClass("cTracsApps");
			var that = this,
				oViewModel, visibleModel, ValueModel;
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var todayDate = dateFormat.format(new Date());
			oViewModel = new JSONModel({
				busyInd: false,
				Role: "",
				Group: "",
				craftTxt: "",
				positonInp: "",
				dateRange: todayDate,
				editable: false,
				enabled: false
			});
			that.getView().setModel(oViewModel, "viewModel");
			visibleModel = new JSONModel({
				editBtn: false,
				cancelBtn: true,
				saveBtn: false,
				submitBtn: false,
				posGlobalTable: false
			});
			that.getView().setModel(visibleModel, "visibleModel");
			ValueModel = new JSONModel({
				positionTitle: "",
				AssignedSuperVisrVal: "",
				cityValue: "",
				CurrOcupntvalue: "",
				DeptVal: "",
				DeskVal: "",
				Uninonval: "",
				StateVal: "",
				DivisionVal: "",
				GangVal: ""
			});
			that.getView().setModel(ValueModel, "ValueModel");
			var mModel = that.getOwnerComponent().getModel();
			mModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			var oRatedModel = new sap.ui.model.json.JSONModel();
			mModel.read("/RatedetSet", null, null, false, function (oRatedData) {
				var oRateData = oRatedData.results;
				oRatedModel.setData(oRateData);
				that.getView().setModel(oRatedModel, "oRatedModel");
			});

			//********************Startup Parameters*****************//
			var oLoggedinUser;
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function () {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					oLoggedinUser = oUserData.id;
					jQuery.sap.require("jquery.sap.storage");
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("UserName", oLoggedinUser);
					that.userDetailsSet(oLoggedinUser);
				}
			};
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

		},
		getDropdownData: function (entity, modelName, filters) {
			var that = this,
				sModel = that.getOwnerComponent().getModel();
			sModel.read(entity, {
				filters: filters,
				success: function (oData, res) {
					if (res.statusCode === '200' || res.statusCode === 200) {
						var oModel = new JSONModel();
						if (oData.results.length > 0) {
							oModel.setData(oData);
							oModel.setSizeLimit(100000);
						} else {
							oModel.setData({
								results: []
							});
						}
						that.getView().setModel(oModel, modelName);
					}
				},
				error: function (err) {
					that.errorHandler(err);
				}
			});
		},
		userDetailsSet: function (userId) {
			var that = this;
			//-----------------------------------------------------------------------	
			// Calling the oData service.
			//-----------------------------------------------------------------------
			var craftTypeModel = that.getOwnerComponent().getModel();
			craftTypeModel.read("/UserDetailsSet?$filter=Uname eq '" + userId + "'", {
				success: function (oData) {
					that.userDetailsSetData = oData; //settting the odata to global variable access the User details 
					var resul = oData.results;
					var rolesArray = resul.slice();
					var roleVals = [];
					for (var i = 0; i < rolesArray.length; i++) {
						var oVal1 = rolesArray[i].Role;
						roleVals.push(oVal1);

						if (oVal1 === "LR Admin") {
							that.getModel("visibleModel").setProperty("/editBtn", false);
							that.getModel("visibleModel").setProperty("/cancelBtn", false);
						}
					}
					var finalArray = that.uniqueValuesFunc(roleVals, "Role");
					var oDataRole = {
						results: finalArray
					};
					var selectedKey1 = oDataRole.results[0].Role;
					var oJModelRole = new sap.ui.model.json.JSONModel(oDataRole);
					that.setModel(oJModelRole, "RoleModel");
					that.getModel("viewModel").setProperty("/Role", selectedKey1);
					//fire the change event of the roles dropdown to get the departments values
					that.byId("roleIdSelect").fireChange(that.byId("roleIdSelect").getSelectedItem());
					that.byId("positonIdInp").setValueState("None");
					that.byId("positonIdInp").setValue();
					that.byId("posMaintId").setShowFooter(true);

				},
				error: function (oResponse) {
					var oMessage = [];
					var msg_len = $(oResponse.response.body).find('message').first().prevObject.length;
					for (var j = 0; j < msg_len; j++) {
						var exception = $(oResponse.response.body).find('message').first().prevObject[j].innerText;
						if (exception !== "Exception raised without specific error") {
							var Message = $(oResponse.response.body).find('message').first().prevObject[j].innerText;
							oMessage.push(Message);
						}
					}
					var uniqueMsgs = [];
					$.each(oMessage, function (i, el) {
						if ($.inArray(el, uniqueMsgs) === -1) uniqueMsgs.push(el);
					});
					var msg = uniqueMsgs.toLocaleString().split(",").join("\r\n");

					if (oMessage === undefined) {
						msg = $(oResponse.response.body).find('message').first().prevObject[0].innerText;
					}
					MessageBox.show(
						msg, {
							icon: MessageBox.Icon.INFORMATION,
							title: "Log",
							actions: [MessageBox.Action.OK]
						});

				}
			});
		},
		onRoleSelectionChange: function (oEvent) {
			var that = this;
			var oSelectedRole = oEvent.getSource().getSelectedKey();
			var selectedRows = [];
			//get the same roles data based on the role selection
			// var oRole = oEvent.getParameter("selectedItem").getProperty("text");
			var oRole = that.byId("roleIdSelect").getSelectedKey();

			if (oRole === "LR Admin") {
				that.getModel("visibleModel").setProperty("/editBtn", false);
				that.getModel("visibleModel").setProperty("/cancelBtn", false);
				that.byId("qualificationIconTab").setVisible(false);
			} else {
				that.getModel("visibleModel").setProperty("/editBtn", true);
				that.getModel("visibleModel").setProperty("/cancelBtn", true);
				that.byId("qualificationIconTab").setVisible(true);
			}
			for (var i = 0; i < that.userDetailsSetData.results.length; i++) {
				if (that.userDetailsSetData.results[i].Role === oSelectedRole) {
					selectedRows.push(that.userDetailsSetData.results[i]);
				}
			}
			//create the array of object of unique departments to bind it to the group dropdown
			var newObj = {};
			var newDepAndUnionsArray = selectedRows.filter(function (obj) {
				if (newObj[obj.Department]) {
					return false;
				}
				newObj[obj.Department] = true;
				return true;
			});

			var oJModel = new sap.ui.model.json.JSONModel(newDepAndUnionsArray);
			oJModel.setDefaultBindingMode("OneWay");
			that.setModel(oJModel, "DepModel");
			that.getModel("viewModel").setProperty("/Group", newDepAndUnionsArray[0].Unions);

			that.craftUnion = newDepAndUnionsArray[0].Department;
			that.Unions = newDepAndUnionsArray[0].Unions;
			if (newDepAndUnionsArray.length === 1 || newDepAndUnionsArray.length === 0) {
				that.byId("depIdSelect").setEnabled(false);
			} else {
				that.byId("depIdSelect").setEnabled(true);
			}
			that.getModel("viewModel").setProperty("/craftTxt", that.craftUnion);

			that.byId("positonIdInp").setValueState("None");
		},
		//-----------------------------------------------------------------------	
		// Position ID Dialogue.
		//-----------------------------------------------------------------------
		onPosIdRequest: function (oEvent) {

			var that = this;
			that.craftUnion = that.getView().getModel("viewModel").getProperty("/Group");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
			if (that.craftUnion === "Engineering" || that.craftUnion === "SE" || that.craftUnion === "SM" || that.craftUnion === "SL" || that.craftUnion ===
				"SD" || that.craftUnion === "SN" || that.craftUnion === "SI" || that.craftUnion === "SC" || that.craftUnion === "SN" || that.craftUnion ===
				"ST") {
				if (!that.oDialog) {
					that.oDialog = sap.ui.xmlfragment("position_maintenance.PositionMaintenance.fragment.PositionId", that.getView()
						.getController());
					that.getView().addDependent(that.oDialog);
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
				}
				// sap.ui.getCore().byId("dialoguEngPosIdTitleSearchId").setValue();
				var engPosIdTitleTable = sap.ui.getCore().byId("engPosIdOrTitleTabTable1");
				if (oEvent.getSource().getValue().trim() !== "") {
					that.oDialog.setBusy(true);
					that.oDialog.setBusyIndicatorDelay(0);
					var engPosId = oEvent.getSource().getValue().trim();
					var engJsonPos = new sap.ui.model.json.JSONModel();
					var engModel = that.getOwnerComponent().getModel("oDataSrv");
					engModel.read("/PositionSearchHelpSet?$filter=PositionId eq '" + engPosId + "' and Key eq 'E'", null, null,
						true,
						function (oData) {
							if (oData.results.length > 0) {
								engJsonPos.setData(oData);
								that.oDialog.setBusy(false);
								engPosIdTitleTable.setModel(engJsonPos, "engPosIdTitleModelData");
								sap.ui.getCore().byId("engPosIdOrTitleTabTable").setVisible(true);
							} else {
								that.oDialog.setBusy(false);
								sap.ui.getCore().byId("engPosIdOrTitleTabTable").setVisible(false);
							}
						},
						function (oResponse) {
							engJsonPos.setData({});
							engPosIdTitleTable.setModel(engJsonPos, "engPosIdTitleModelData");
							//-----------------------------------------------------------------------	
							// Displaying response body message.
							//-----------------------------------------------------------------------
							that.oDialog.setBusy(false);
							var oMessage;
							oMessage = JSON.parse(oResponse.response.body).error.message.value;
							sap.m.MessageBox.show(oMessage, {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: titleInfo,
								actions: [sap.m.MessageBox.Action.OK]
							});
						});
					that.oDialog.open();
					sap.ui.getCore().byId("idEngIconTabBar").setSelectedKey("Position ID or Title");
					that.posIdDialog = "X";
				} else {
					that.oDialog.open();
					that.posIdDialog = "X";
				}
			}
		},

		onPayDialogCancel: function () {
			/*this._payRollPosIdValueDialog.close();*/
			sap.ui.getCore().byId("payRollPosId").setValue("");
			sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);

			this._payRollPosIdValueDialog.close();
			this._payRollPosIdValueDialog.destroy(true);
			this._payRollPosIdValueDialog = null;
		},

		onPayPosSearch: function () {
			var posIdOrTitle = sap.ui.getCore().byId("payRollPosId").getValue();
			if (posIdOrTitle !== "") {
				var property = "PositionId eq '" + posIdOrTitle + "'";
				var type = "Search";
				this.payrollPositiontableData(property, type);
			} else {
				sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
			}
		},

		onPayRollUnionSelectionChange: function () {
			var Union = sap.ui.getCore().byId("payRollUnionDropDown").getValue();
			if (Union !== "") {
				var property = "Union eq '" + Union + "'";
				var type = "Search";
				this.payrollPositiontableData(property, type);
			} else {
				sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
			}
		},

		onPayRollAggSelectionChange: function () {
			var Aggcode = sap.ui.getCore().byId("payRollAggCode").getValue();
			if (Aggcode !== "") {
				var property = "AgreementCode eq '" + Aggcode + "'";
				var type = "Search";
				this.payrollPositiontableData(property, type);
			} else {
				sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
			}
		},

		onPayrollEmpSearch: function () {
			var empId = sap.ui.getCore().byId("payRollEmpcode").getValue();
			if (empId !== "") {
				var property = "EmployeeId eq '" + empId + "'";
				var type = "Search";
				this.payrollPositiontableData(property, type);
			} else {
				sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
			}
		},

		onPayRollCostSearch: function () {
			var costCenter = sap.ui.getCore().byId("payrollCostcenter").getValue();
			if (costCenter !== "") {
				var property = "CostCenter eq '" + costCenter + "'";
				var type = "Search";
				this.payrollPositiontableData(property, type);
			} else {
				sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
			}
		},

		payRollIconTabBarSelect: function () {
			sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
			sap.ui.getCore().byId("payRollPosId").setValue("");
			sap.ui.getCore().byId("payRollEmpcode").setValue("");
			sap.ui.getCore().byId("payRollUnionDropDown").setValue("");
			sap.ui.getCore().byId("payRollUnionDropDown").setSelectedKey("");
			sap.ui.getCore().byId("payRollAggCode").setValue("");
			sap.ui.getCore().byId("payRollAggCode").setSelectedKey("");
			sap.ui.getCore().byId("payrollCostcenter").setValue("");
		},

		onPayrollPositionSubmit: function (oEvent) {
			var context = oEvent.getSource().getBindingContext("payRollPosDetails");
			var data = context.getModel().getProperty(context.getPath());
			this.getView().byId("positonIdInp").setValue(data.PositionId);

			if (data.PositionDesc !== "") {
				this.getView().byId("positonIdInp").setDescription(data.PositionDesc).setWidth("25%");
			}
			this.payCraft = data.Craft;
			this.onPositionSubmitInput();
			this.onPayDialogCancel();
		},

		payrollPositiontableData: function (property, type) {
			var that = this;
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			/*var dialog = new sap.m.BusyDialog({

			});
			dialog.open();*/
			var posIdTitleJsonPos = new sap.ui.model.json.JSONModel();
			var posIdTitleModel = that.getOwnerComponent().getModel("oDataSrv");
			posIdTitleModel.read("/PositionSearchHelpSet?$filter=" + property + " and Key eq 'P'", null, null,
				true,
				function (oData) {

					if (type === "Search") {
						that._payRollPosIdValueDialog.setBusy(false);
						if (oData.results.length > 0) {
							posIdTitleJsonPos.setData(oData);
							var posIdTitleTable = sap.ui.getCore().byId("payRollPosIdTabTable");
							posIdTitleTable.setModel(posIdTitleJsonPos, "payRollPosDetails");
							sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
						}
					} else {
						that.payCraft = oData.results[0].Craft;
						//	that._payRollPosIdValueDialog.setBusy(false);
					}
					// dialog.close();
				},
				function (oResponse) {

					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					// dialog.close();
					that._payRollPosIdValueDialog.setBusy(false);
					var oMessage;
					var mesLen = $(oResponse.response.body).find("message").first().prevObject.length;
					for (var i = 1; i < mesLen; i++) {
						var exception = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
						if (exception !== "Exception raised without specific error") {
							var Message = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
						} else {

							Message = "";

						}
						if (i === 1) {
							oMessage = Message;
						}
						if (i > 1) {
							oMessage = oMessage + "\r\n" + Message;
						}
					}

					if (oMessage === undefined) {
						oMessage = $(oResponse.response.body).find("message").first().prevObject[0].innerText;
					}

					sap.m.MessageBox.show(oMessage, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: titleInfo,
						actions: [sap.m.MessageBox.Action.OK],

						onClose: function (oAction) {
							if (oAction === "OK") {
								if (sap.ui.getCore().byId("payRollPosIdTabTable") !== undefined) {
									sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
								}
							}
						}

					});

				});
		},
		onDialogClose: function () {
			var that = this;
			that.oDialog.close();
			that.oDialog.destroy();
			that.oDialog = null;
		},
		errorMessageforHelp: function (oResponse, titleInfo) {
			var oMessage;
			oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;
			sap.m.MessageBox.show(oMessage, {
				icon: sap.m.MessageBox.Icon.INFORMATION,
				title: titleInfo,
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function (oAction) {}
			});
		},
		onUnionDropDown: function () {
			var that = this;
			if (that.craftUnion === "Engineering" || that.craftUnion === "SE") {
				that.GrpValue = "E";
			} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM") {
				that.GrpValue = "M";
			} else if (that.craftUnion === "Conrail" || that.craftUnion === "SC") {
				that.GrpValue = "C";
			} else if (that.craftUnion === "IHB" || that.craftUnion === "SI") {
				that.GrpValue = "I";
			} else if (that.craftUnion === "NAHR" || that.craftUnion === "SN") {
				that.GrpValue = "N";
			} else if (that.craftUnion === "Payroll" || that.craftUnion === "SE") {
				that.GrpValue = "P";
			} else if (that.craftUnion === "ILA" || that.craftUnion === "SL") {
				that.GrpValue = "P";
			}
			var unionModel = that.getOwnerComponent().getModel();
			var sFilters = [];
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, "U"));
			sFilters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, that.GrpValue));
			unionModel.read("/PosDropDownsSet", {
				filters: sFilters,
				success: function (oData) {
					var oUninonModel = new sap.ui.model.json.JSONModel(oData);
					that.getView().setModel(oUninonModel, "UninonModel");
				},
				error: function (oResponse) {
					that.errorMessageforHelp();
				}
			});
		},
		// errorMessageforHelp: function (oResponse, titleInfo) {
		// 	var oMessage;
		// 	var mesLen = $(oResponse.response.body).find("message").first().prevObject.length;
		// 	for (var i = 1; i < mesLen; i++) {
		// 		var exception = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
		// 		if (exception !== "Exception raised without specific error") {
		// 			var Message = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
		// 		} else {
		// 			Message = "";
		// 		}
		// 		if (i === 1) {
		// 			oMessage = Message;
		// 		}
		// 		if (i > 1) {
		// 			oMessage = oMessage + "\r\n" + Message;
		// 		}
		// 	}
		// 	if (oMessage === undefined) {
		// 		oMessage = $(oResponse.response.body).find("message").first().prevObject[0].innerText;
		// 	}
		// 	sap.m.MessageBox.show(oMessage, {
		// 		icon: sap.m.MessageBox.Icon.INFORMATION,
		// 		title: titleInfo,
		// 		actions: [sap.m.MessageBox.Action.OK],
		// 		onClose: function (oAction) {}
		// 	});
		// },
		uninonSelectionChanges: function (oEvent) {
			var that = this,
				GrpValue;
			if (that.craftUnion === "Engineering" || that.craftUnion === "SE") {
				GrpValue = "E";
			} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM") {
				GrpValue = "M";
			} else if (that.craftUnion === "Conrail" || that.craftUnion === "SC") {
				GrpValue = "C";
			} else if (that.craftUnion === "IHB" || that.craftUnion === "SI") {
				GrpValue = "I";
			} else if (that.craftUnion === "NAHR" || that.craftUnion === "SN") {
				GrpValue = "N";
			} else if (that.craftUnion === "Payroll" || that.craftUnion === "SE") {
				GrpValue = "P";
			} else if (that.craftUnion === "ILA" || that.craftUnion === "SL") {
				GrpValue = "P";
			}
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var posUnion = oEvent.getParameter("selectedItem").getProperty("text");
			var posUnionModel = that.getOwnerComponent().getModel();
			var sFilters = [];
			sFilters.push(new sap.ui.model.Filter("Union", sap.ui.model.FilterOperator.EQ, posUnion));
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			posUnionModel.read("/PositionSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var oUninonModel = new sap.ui.model.json.JSONModel(oData.results);
						that.getView().setModel(oUninonModel, "positionModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				error: function (oResponse) {
					that.errorMessageforHelp(oResponse, titleInfo);
				}
			});
		},
		StateSearchHelpSet: function () {
			var that = this;
			var stateModel = that.getOwnerComponent().getModel();
			var sFilters = [];
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, "S"));
			sFilters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, ""));
			stateModel.read("/PosDropDownsSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var oStateModel = new sap.ui.model.json.JSONModel(oData.results);
						that.getView().setModel(oStateModel, "stateModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				error: function (oResponse) {
					that.errorMessageforHelp(oResponse);
				}
			});
		},
		stateSelectionChange: function (oEvent) {
			var that = this,
				GrpValue;
			if (that.craftUnion === "Engineering" || that.craftUnion === "SE") {
				GrpValue = "E";
			} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM") {
				GrpValue = "M";
			} else if (that.craftUnion === "Conrail" || that.craftUnion === "SC") {
				GrpValue = "C";
			} else if (that.craftUnion === "IHB" || that.craftUnion === "SI") {
				GrpValue = "I";
			} else if (that.craftUnion === "NAHR" || that.craftUnion === "SN") {
				GrpValue = "N";
			} else if (that.craftUnion === "Payroll" || that.craftUnion === "SE") {
				GrpValue = "P";
			} else if (that.craftUnion === "ILA" || that.craftUnion === "SL") {
				GrpValue = "P";
			}
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var posStateVal = oEvent.getParameter("selectedItem").getProperty("text");
			var posUnionModel = that.getOwnerComponent().getModel();
			var sFilters = [];
			sFilters.push(new sap.ui.model.Filter("State", sap.ui.model.FilterOperator.EQ, posStateVal));
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			posUnionModel.read("/PositionSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var oUninonModel = new sap.ui.model.json.JSONModel(oData.results);
						that.getView().setModel(oUninonModel, "positionModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				error: function (oResponse) {
					that.errorMessageforHelp(oResponse, titleInfo);
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
				}
			});
		},
		divisionDropdown: function () {
			var that = this;
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var DivModel = that.getOwnerComponent().getModel();
			var sFilters = [];
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, "D"));
			sFilters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, ""));
			DivModel.read("/PosDropDownsSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var divisionModel = new sap.ui.model.json.JSONModel(oData);
						that.getView().setModel(divisionModel, "DivisnModelData");
					} else {
						//	sap.ui.getCore().byId("engUnionTabTable").setVisible(false);
					}
				},
				error: function (oResponse) {
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					var oMessage;
					var mesLen = $(oResponse.response.body).find("message").first().prevObject.length;
					for (var i = 1; i < mesLen; i++) {
						var exception = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
						if (exception !== "Exception raised without specific error") {
							var Message = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
						} else {
							Message = "";
						}
						if (i === 1) {
							oMessage = Message;
						}
						if (i > 1) {
							oMessage = oMessage + "\r\n" + Message;
						}
					}
					if (oMessage === undefined) {
						oMessage = $(oResponse.response.body).find("message").first().prevObject[0].innerText;
					}
					sap.m.MessageBox.show(oMessage, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: titleInfo,
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {}
					});
				}
			});
		},
		onDivSelectionChange: function (oEvent) {
			var that = this,
				GrpValue;
			if (that.craftUnion === "Engineering" || that.craftUnion === "SE") {
				GrpValue = "E";
			} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM") {
				GrpValue = "M";
			} else if (that.craftUnion === "Conrail" || that.craftUnion === "SC") {
				GrpValue = "C";
			} else if (that.craftUnion === "IHB" || that.craftUnion === "SI") {
				GrpValue = "I";
			} else if (that.craftUnion === "NAHR" || that.craftUnion === "SN") {
				GrpValue = "N";
			} else if (that.craftUnion === "Payroll" || that.craftUnion === "SE") {
				GrpValue = "P";
			} else if (that.craftUnion === "ILA" || that.craftUnion === "SL") {
				GrpValue = "P";
			}
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var posDiv = oEvent.getParameter("selectedItem").getProperty("text");
			posDiv = posDiv.replace(/&/g, "%26");
			var posUnionModel = that.getOwnerComponent().getModel();
			var sFilters = [];
			sFilters.push(new sap.ui.model.Filter("Divison", sap.ui.model.FilterOperator.EQ, posDiv));
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			posUnionModel.read("/PositionSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var oUninonModel = new sap.ui.model.json.JSONModel(oData.results);
						that.getView().setModel(oUninonModel, "positionModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				error: function (oResponse) {
					that.errorMessageforHelp(oResponse, titleInfo);
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
				}
			});
		},
		//-----------------------------------------------------------------------	
		// Method for gettting uniq drop down values.
		//-----------------------------------------------------------------------
		uniqueDropDownValFun: function (oUniqJsonModel, Value) {
			var oArray = [];
			var checkArray = [];
			for (var i = 0; i < oUniqJsonModel.length; i++) {
				if (oArray.indexOf(oUniqJsonModel[i]["" + Value + ""]) === -1 && oUniqJsonModel[i]["" + Value + ""].trim() !== "") {
					oArray.push(oUniqJsonModel[i]["" + Value + ""]);
					var uObj = Object.assign({}, oUniqJsonModel[i]);
					checkArray.push(uObj);
				}
			}
			return checkArray;
		},
		gangIdDropdown: function () {
			var that = this;
			var sFilters = [];
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, "G"));
			sFilters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, ""));
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/PosDropDownsSet", {
				filters: sFilters,
				success: function (oData) {
					var gangMdel = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(gangMdel, "GangModelDrop");
					var oUniqJsonModel = that.getView().getModel("GangModelDrop").getData().results;
					var uniqDivArr = that.uniqueDropDownValFun(oUniqJsonModel, "Value");
					var oGangIdArray = {
						results: uniqDivArr
					};
					var oGangIdModel = new sap.ui.model.json.JSONModel(oGangIdArray);
					oGangIdModel.setSizeLimit(oData.results.length);
					var sModel = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(sModel, "GangModelDropModel");
				},
				error: function (oResponse) {
					that.errorMessageFun(oResponse);
				}
			});
		},
		ongangSelectionChnage: function (oEvent) {
			var that = this,
				GrpValue;
			if (that.craftUnion === "Engineering" || that.craftUnion === "SE") {
				GrpValue = "E";
			} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM") {
				GrpValue = "M";
			} else if (that.craftUnion === "Conrail" || that.craftUnion === "SC") {
				GrpValue = "C";
			} else if (that.craftUnion === "IHB" || that.craftUnion === "SI") {
				GrpValue = "I";
			} else if (that.craftUnion === "NAHR" || that.craftUnion === "SN") {
				GrpValue = "N";
			} else if (that.craftUnion === "Payroll" || that.craftUnion === "SE") {
				GrpValue = "P";
			} else if (that.craftUnion === "ILA" || that.craftUnion === "SL") {
				GrpValue = "P";
			}
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var posGangId = oEvent.getSource().getValue();
			var posUnionModel = that.getOwnerComponent().getModel();
			var sFilters = [];
			sFilters.push(new sap.ui.model.Filter("GangId", sap.ui.model.FilterOperator.EQ, posGangId));
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			posUnionModel.read("/PositionSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var oUninonModel = new sap.ui.model.json.JSONModel(oData.results);
						that.getView().setModel(oUninonModel, "positionModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				error: function (oResponse) {
					that.errorMessageforHelp(oResponse, titleInfo);
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
				}
			});

		},
		positionTitleSearch: function (oEvent) {
			var that = this,
				GrpValue, sFilters = [];
			var SeltedKeyTabbar = oEvent.getSource().getParent().getParent().getKey();
			var posValue = that.getView().getModel("ValueModel").getProperty("/positionTitle");
			var DeptVal = that.getView().getModel("ValueModel").getProperty("/DeptVal");
			var DeskVal = that.getView().getModel("ValueModel").getProperty("/DeskVal");
			var oModel = that.getOwnerComponent().getModel();
			if (that.craftUnion === "Engineering" || that.craftUnion === "SE") {
				GrpValue = "E";
			} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM") {
				GrpValue = "M";
			} else if (that.craftUnion === "Conrail" || that.craftUnion === "SC") {
				GrpValue = "C";
			} else if (that.craftUnion === "IHB" || that.craftUnion === "SI") {
				GrpValue = "I";
			} else if (that.craftUnion === "NAHR" || that.craftUnion === "SN") {
				GrpValue = "N";
			} else if (that.craftUnion === "Payroll" || that.craftUnion === "SE") {
				GrpValue = "P";
			} else if (that.craftUnion === "ILA" || that.craftUnion === "SL") {
				GrpValue = "P";
			}
			if (SeltedKeyTabbar === "Position ID or Title") {
				sFilters.push(new sap.ui.model.Filter("PositionId", sap.ui.model.FilterOperator.EQ, posValue));
				sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			} else if (SeltedKeyTabbar === "Assigned Supervisor") {
				var AssignedVal = that.getView().getModel("ValueModel").getProperty("/AssignedSuperVisrVal");
				sFilters.push(new sap.ui.model.Filter("AssignSup", sap.ui.model.FilterOperator.EQ, AssignedVal));
				sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			} else if (SeltedKeyTabbar === "City") {
				var Cityval = that.getView().getModel("ValueModel").getProperty("/cityValue");
				sFilters.push(new sap.ui.model.Filter("City", sap.ui.model.FilterOperator.EQ, Cityval));
				sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			} else if (SeltedKeyTabbar === "Current Occupant") {
				var Currentcupant = that.getView().getModel("ValueModel").getProperty("/CurrOcupntvalue");
				sFilters.push(new sap.ui.model.Filter("CurntOcupnt", sap.ui.model.FilterOperator.EQ, Currentcupant));
				sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			} else if (SeltedKeyTabbar === "Union") {
				var unionVal = oEvent.getParameter("selectedItem").getProperty("text");
				sFilters.push(new sap.ui.model.Filter("CurntOcupnt", sap.ui.model.FilterOperator.EQ, unionVal));
				sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			} else if (SeltedKeyTabbar === "Department") {
				sFilters.push(new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.EQ, DeptVal));
				sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			} else if (SeltedKeyTabbar === "Desk") {
				sFilters.push(new sap.ui.model.Filter("Desk", sap.ui.model.FilterOperator.EQ, DeskVal));
				sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			}
			oModel.read("/PositionSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var oUninonModel = new sap.ui.model.json.JSONModel(oData.results);
						that.getView().setModel(oUninonModel, "positionModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				error: function (oResponse) {
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					that.errorMessageforHelp(oResponse);
				}
			});
		},
		onSelectIconTabBar: function () {
			var that = this;
			that.getView().getModel("positionModelData").setData([]);
			that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
			that.getView().getModel("ValueModel").setProperty("/positionTitle", "");
			that.getView().getModel("ValueModel").setProperty("/AssignedSuperVisrVal", "");
			that.getView().getModel("ValueModel").setProperty("/cityValue", "");
			that.getView().getModel("ValueModel").setProperty("/CurrOcupntvalue", "");
			that.getView().getModel("ValueModel").setProperty("/DeptVal", "");
			that.getView().getModel("ValueModel").setProperty("/Uninonval", "");
			that.getView().getModel("ValueModel").setProperty("/StateVal", "");
			that.getView().getModel("ValueModel").setProperty("/DivisionVal", "");
			that.getView().getModel("ValueModel").setProperty("/GangVal", "");
		},
		onPositionSubmit: function () {
			var that = this;
			that.onDialogClose();
		},
		handleIconTabBarSelect: function () {
			var that = this,
				posVal, GrpValue;
			if (that.craftUnion === "Engineering" || that.craftUnion === "SE") {
				GrpValue = "E";
			} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM") {
				GrpValue = "M";
			} else if (that.craftUnion === "Conrail" || that.craftUnion === "SC") {
				GrpValue = "C";
			} else if (that.craftUnion === "IHB" || that.craftUnion === "SI") {
				GrpValue = "I";
			} else if (that.craftUnion === "NAHR" || that.craftUnion === "SN") {
				GrpValue = "N";
			} else if (that.craftUnion === "Payroll" || that.craftUnion === "SE") {
				GrpValue = "P";
			} else if (that.craftUnion === "Dispatchers" || that.craftUnion === "ATDA") {
				GrpValue = "A";
			} else if (that.craftUnion === "TCU" || that.craftUnion === "ST") {
				GrpValue = "T";
			} else if (that.craftUnion === "ILA" || that.craftUnion === "SL") {
				GrpValue = "P";
			}
			var aRole = that.byId("roleIdSelect").getSelectedKey();
			if (aRole === "LR Admin") {
				that.getModel("visibleModel").setProperty("/editBtn", false);
				that.getModel("visibleModel").setProperty("/cancelBtn", false);
			}
			if (that.oEditAll) {
				sap.m.MessageBox.show("Please Save/Cancel the unsaved changes", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				that.byId("posMaintIconTabBar").setSelectedKey(this.aSelected);
			} else if (that.getView().byId("submitId").getEnabled() === true) {
				sap.m.MessageBox.show("Please Submit/Cancel the unsaved changes", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				that.byId("posMaintIconTabBar").setSelectedKey("QUALIFICATION"); // ""
			}
			if (this.byId("posMaintIconTabBar").getSelectedKey() === "QUALIFICATION") {
				//	this.byId("positonIdInp").setWidth("15%");
				this.byId("submitId").setVisible(false).setEnabled(false);
				if (posVal !== "" && posVal.length === 8) {
					that.byId("posMaintId").setBusy(true);
					that.byId("posMaintId").setBusyIndicatorDelay(0);
					that.getModel("visibleModel").setProperty("/editBtn", true);
					if (that.byId("roleIdSelect").getSelectedKey() === "Certification Group") {
						that.getModel("visibleModel").setProperty("/editBtn", false);
						that.getModel("visibleModel").setProperty("/cancelBtn", false);
					}
					// initially, set edit icon disabled and enable it when edit button is pressed		
					var data = this.byId("selectedQualTable").getItems();
					for (var i = 0; i < data.length; i++) {
						data[i].getAggregation("cells")[9].getItems()[1].setEnabled(false);
					}
				} else {
					this.byId("editId").setEnabled(false).setVisible(true);
					if (that.byId("roleIdSelect").getSelectedKey() === "Certification Group") {
						that.byId("editId").setVisible(false);
						that.byId("cancelId").setVisible(false);
					}
				}
				this.byId("saveId").setVisible(false);
				if (this.byId("positonIdInp").getTokens().length !== 0 && this.byId("positonIdInp").getValueState() !== "Error") {
					this.qualificationTab();
				}
				if (craftType === "Payroll") {
					this.getView().byId("editId").setEnabled(false);
					this.getView().byId("cancelId").setEnabled(false);
				}
				this.byId("qualStartDateId").setEnabled(false);
				this.byId("qualifIdInp").setEnabled(false);
				this.byId("posAssignId").setEnabled(false);
				this.byId("qualEndDateId").setEnabled(false);

				var data = this.byId("selectedQualTable").getItems();
				for (var i = 0; i < data.length; i++) {
					data[i].getAggregation("cells")[9].getItems()[1].setEnabled(false);
				}
			}
		}
	});
});