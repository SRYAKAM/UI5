sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.SR_12-12-2022SR_12-12-2022.controller.App", {

	});
});