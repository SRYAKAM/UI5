// var inlineTable;
var titleError;
var close;
// var stateComboBox;
sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter",
	"sap/m/DatePicker"
], function (BaseController, JSONModel, History, formatter, DatePicker) {
	"use strict";
	var fileDataArr = [];

	return BaseController.extend("com.empqualassignment.Employee_Qual_Assignment.controller.QualDispEdit", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var that = this;
			that.getRouter().getRoute("QualDispEdit").attachPatternMatched(that._onObjectMatched, that);

		},

		_onObjectMatched: function (oEvent) {
			var that = this;

			that.srvResp = "No";
			// var oController = that.getView().getController();
			that.stateDataFun();

			var oJsonModel = new JSONModel();
			oJsonModel.setData({});
			that.getView().setModel(oJsonModel, "oJsonModel");
			var stateComboBox = new sap.m.ComboBox({
				// liveChange: function (oEvt) {
				// 	oEvt.getSource().setValue("");
				// },
				change: function (oEvt) {
					if (oEvt.getSource().getSelectedKey() === "") {
						oEvt.getSource().setValue("");
					}
					oEvt.getSource().setValueState("None");
				}
			}).addStyleClass("comboCls");
			var oStateTemp = new sap.ui.core.ListItem({
				key: "{stateData>State}",
				text: "{stateData>State}"
			});

			stateComboBox.bindItems({
				path: "stateData>/results",
				template: oStateTemp
			});
			that.stateComboBox = stateComboBox;
			var emptyArr = [];
			var oEmptyModel = new sap.ui.model.json.JSONModel(emptyArr);
			var attachmentsTable = that.byId("uploadAttachmentsTable");
			attachmentsTable.setModel(oEmptyModel, "oAttachData");
			/*	var inlineTable = new sap.m.Table({
					// id: "uploadAttachmentsTable",
					columns: [new sap.m.Column({
							header: new sap.m.Label({
								text: "Attachment",
								design: "Bold"
							})
						}),
						new sap.m.Column({
							visible: false,
							header: new sap.m.Label({
								text: "Data"
							})
						}),
						new sap.m.Column({
							header: new sap.m.Label({
								text: ""
							})
						})
					]
				}).addStyleClass("clsTableHeader clsColumnHeader clsTableRows");
				inlineTable.bindItems("oAttachData>/", new sap.m.ColumnListItem({
					cells: [
						new sap.m.Link({
							text: "{oAttachData>DocName}",
							press: [oController.onFileDownload, oController]
						}),
						new sap.m.Input({
							value: "{oAttachData>DocData}"
						}),
						new sap.m.Button({
							icon: "sap-icon://delete",
							press: [oController.onFileDelete, oController]
						}).addStyleClass("clsBtnColorYellowRed")
					]
				}));*/
			// var oContent = that.byId("additionalInfoPanel").getContent();
			// var tableId = oContent[2].getId();
			// sap.ui.getCore().setModel(oEmptyModel, "oAttachData");
			//INLPAT
			var empNo = oEvent.getParameter("arguments").empNo;
			var qualID = oEvent.getParameter("arguments").qualId;
			that.qualId = qualID;
			var effDate = oEvent.getParameter("arguments").effDate;
			var oEffectiveDate = effDate.substring(4, 6) + "/" + effDate.substring(6, 8) + "/" + effDate.substring(0, 4);
			var craft = oEvent.getParameter("arguments").craft;
			var craftType;
			if (craft === "Engineering") {
				craftType = "TRACS - Engineering";
			} else if (craft === "Mechanical") {
				craftType = "TRACS - Mechanica";
			} else if (craft === "TCU") {
				craftType = "TRACS - TCU";
			}

			that.craftType = craftType;

			var qualDesc = decodeURIComponent(oEvent.getParameter("arguments").qualDesc);
			var startDate = oEvent.getParameter("arguments").startDate;
			var oStartDate = startDate.substring(4, 6) + "/" + startDate.substring(6, 8) + "/" + startDate.substring(0, 4);
			var endDate = oEvent.getParameter("arguments").endDate;
			var oEndDate = endDate.substring(4, 6) + "/" + endDate.substring(6, 8) + "/" + endDate.substring(0, 4);
			var profScale = oEvent.getParameter("arguments").profScale;
			var type = oEvent.getParameter("arguments").type;
			that.type = type;

			that.byId("dispEditEmpNo").setText(empNo);
			that.byId("dispEditEnDate").setValue(oEndDate);
			that.byId("dispEditQualInp").setText(that.qualId);
			that.byId("dispEditQualInpDes").setText(qualDesc);
			that.byId("dispEditEffDate").setValue(effDate);
			that.byId("dispEditProfScale").setText(profScale);
			that.byId("dispEditStDate").setText(oStartDate);
			that.byId("dispEditCraftType").setText(craft);

			if (type === "Edit") {
				that.byId("dispEditSaveBtn").setVisible(true);
				that.byId("dispEditCancelBtn").setVisible(true);
				that.byId("dispEditDelimitBtn").setVisible(false);
				that.byId("dispEditAdditionalInfoPanel").setVisible(true);
				that.byId("dispEditEnDate").setEnabled(true);
			} else if (type === "Display") {
				that.byId("dispEditSaveBtn").setVisible(false);
				that.byId("dispEditCancelBtn").setVisible(true);
				that.byId("dispEditDelimitBtn").setVisible(false);
				that.byId("dispEditAdditionalInfoPanel").setVisible(true);
					that.byId("dispEditEnDate").setEnabled(false);
			} else if (type === "Delimit") {
				that.byId("dispEditSaveBtn").setVisible(false);
				that.byId("dispEditCancelBtn").setVisible(true);
				that.byId("dispEditDelimitBtn").setVisible(true);
				that.byId("dispEditAdditionalInfoPanel").setVisible(false);
				that.byId("dispEditEnDate").setEnabled(false);
			}

			if (type !== "Delimit") {

				var titleInfo = this.getView().getModel("i18n").getProperty("titleInfo");
				var ok = this.getView().getModel("i18n").getProperty("ok");

				//-----------------------------------------------------------------------	
				//Busy Indicator.
				//-----------------------------------------------------------------------

				var dialog = new sap.m.BusyDialog({

				});

				dialog.open();

				// that.defaultDate();

				var queryFil = [];
				var empNum = new sap.ui.model.Filter("Pernr", "EQ", empNo);
				var EffDate = new sap.ui.model.Filter("EffDate", "EQ", effDate);
				var Key = new sap.ui.model.Filter("Key", "EQ", "D");
				queryFil.push(empNum);
				queryFil.push(EffDate);
				queryFil.push(Key);

				var oModel = that.getOwnerComponent().getModel();
				//"/QualAddHeaderSet(QualId='" + that.QualId + "',EmpId='" + that.empId +
				//	"',Timestamp='" + that.timeStamp + "')?$expand=QualDetailsNavi,QualDocNavi"
				oModel.read("/QualAddHeaderSet(QualId='" + qualID + "',EmpId='" + empNo + "',Key='EQA',Timestamp='',SubDate='')", {
					urlParameters: {
						"$expand": "QualDetailsNavi,QualDocNavi"
					},
					async: false,
					success: function (oData) {
						dialog.close();
						// if (oData.results.length > 0) {

						that.attachArr = [];
						var columnsArr1 = [];
						that.columnsArray1 = [];
						var columnsArr = [];
						that.columnsArray = [];
						for (var i = 0; i < oData.QualDetailsNavi.results.length; i++) {
							// var columnsArr = [];
							// that.columnsArray = [];
							// if (oData.results[i].Qualif === qualID) {

							// var cf = i + 1;
							// var colf = "AddField" + cf;
							// var columnsObj = {};
							var columnsObj1 = {
								AddField: oData.QualDetailsNavi.results[i].Label + ":" + oData.QualDetailsNavi.results[i].Value + ":" + oData.QualDetailsNavi
									.results[
										i].Type + ":" + oData.QualDetailsNavi.results[i].Mandt
							};
							columnsArr1.push(columnsObj1);
							that.columnsArray.push(columnsObj1);
							//oData.QualDetailsNavi.results[0].Value
							// var AddField1;
							// if (oData.results[i].AddField1 !== "") {
							// 	AddField1 = oData.results[i].AddField1;
							// 	columnsObj.AddField1 = oData.results[i].AddField1;
							// } else {
							// 	AddField1 = oData.results[i].AddField1;
							// }
							// var AddField2;
							// if (oData.results[i].AddField2 !== "") {
							// 	AddField2 = oData.results[i].AddField2;
							// 	columnsObj.AddField2 = oData.results[i].AddField2;
							// } else {
							// 	AddField2 = oData.results[i].AddField2;
							// }
							// var AddField3;
							// if (oData.results[i].AddField3 !== "") {
							// 	AddField3 = oData.results[i].AddField3;
							// 	columnsObj.AddField3 = oData.results[i].AddField3;
							// } else {
							// 	AddField3 = oData.results[i].AddField3;
							// }
							// var AddField4;
							// if (oData.results[i].AddField4 !== "") {
							// 	AddField4 = oData.results[i].AddField4;
							// 	columnsObj.AddField4 = oData.results[i].AddField4;
							// } else {
							// 	AddField4 = oData.results[i].AddField4;
							// }
							// var AddField5;
							// if (oData.results[i].AddField5 !== "") {
							// 	AddField5 = oData.results[i].AddField5;
							// 	columnsObj.AddField5 = oData.results[i].AddField5;
							// } else {
							// 	AddField5 = oData.results[i].AddField5;
							// }
							// var AddField6;
							// if (oData.results[i].AddField6 !== "") {
							// 	AddField6 = oData.results[i].AddField6;
							// 	columnsObj.AddField6 = oData.results[i].AddField6;
							// } else {
							// 	AddField6 = oData.results[i].AddField6;
							// }
							// var AddField7;
							// if (oData.results[i].AddField7 !== "") {
							// 	AddField7 = oData.results[i].AddField7;
							// 	columnsObj.AddField7 = oData.results[i].AddField7;
							// } else {
							// 	AddField7 = oData.results[i].AddField7;
							// }
							// var AddField8;
							// if (oData.results[i].AddField8 !== "") {
							// 	AddField8 = oData.results[i].AddField8;
							// 	columnsObj.AddField8 = oData.results[i].AddField8;
							// } else {
							// 	AddField8 = oData.results[i].AddField8;
							// }
							// var AddField9;
							// if (oData.results[i].AddField9 !== "") {
							// 	AddField9 = oData.results[i].AddField9;
							// 	columnsObj.AddField9 = oData.results[i].AddField9;
							// } else {
							// 	AddField9 = oData.results[i].AddField9;
							// }
							// var AddField10;
							// if (oData.results[i].AddField10 !== "") {
							// 	AddField10 = oData.results[i].AddField10;
							// 	columnsObj.AddField10 = oData.results[i].AddField10;
							// } else {
							// 	AddField10 = oData.results[i].AddField10;
							// }

							// that.columnsArray.push(columnsObj);

							// if (AddField1 !== "") {
							// 	columnsArr.push(AddField1);
							// }
							// if (AddField2 !== "") {
							// 	columnsArr.push(AddField2);
							// }
							// if (AddField3 !== "") {
							// 	columnsArr.push(AddField3);
							// }
							// if (AddField4 !== "") {
							// 	columnsArr.push(AddField4);
							// }
							// if (AddField5 !== "") {
							// 	columnsArr.push(AddField5);
							// }
							// if (AddField6 !== "") {
							// 	columnsArr.push(AddField6);
							// }
							// if (AddField7 !== "") {
							// 	columnsArr.push(AddField7);
							// }
							// if (AddField8 !== "") {
							// 	columnsArr.push(AddField8);
							// }
							// if (AddField9 !== "") {
							// 	columnsArr.push(AddField9);
							// }
							// if (AddField10 !== "") {
							// 	columnsArr.push(AddField10);
							// }

							// }
						}
						for (var j = 0; j < oData.QualDocNavi.results.length; j++) {
							var attachObj = {};
							// if (oData.results[i].DocName !== "") {
							attachObj.DocName = oData.QualDocNavi.results[j].DocName;
							attachObj.DocData = oData.QualDocNavi.results[j].Document;

							that.attachArr.push(attachObj);
						}
						// }

						// for (var r = 0; r < columnsArr1.length; r++) {

						// 	if (r === 0) {
						// 		columnsArr.push({
						// 			AddField1: columnsArr1[r].AddField
						// 		});
						// 	} else if (r === 1) {
						// 		columnsArr.push({
						// 			AddField2: columnsArr1[r].AddField
						// 		});
						// 	} else if (r === 2) {
						// 		columnsArr.push({
						// 			AddField3: columnsArr1[r].AddField
						// 		});
						// 	} else if (r === 3) {
						// 		columnsArr.push({
						// 			AddField4: columnsArr1[r].AddField
						// 		});
						// 	} else if (r === 4) {
						// 		columnsArr.push({
						// 			AddField5: columnsArr1[r].AddField
						// 		});
						// 	} else if (r === 5) {
						// 		columnsArr.push({
						// 			AddField6: columnsArr1[r].AddField
						// 		});
						// 	} else if (r === 6) {
						// 		columnsArr.push({
						// 			AddField7: columnsArr1[r].AddField
						// 		});
						// 	} else if (r === 7) {
						// 		columnsArr.push({
						// 			AddField8: columnsArr1[r].AddField
						// 		});
						// 	} else if (r === 8) {
						// 		columnsArr.push({
						// 			AddField9: columnsArr1[r].AddField
						// 		});
						// 	} else if (r === 9) {
						// 		columnsArr.push({
						// 			AddField10: columnsArr1[r].AddField
						// 		});
						// 	}

						// }
						columnsArr = columnsArr1;
						var oJsonModel1 = new JSONModel();
						oJsonModel1.setData(columnsArr);
						that.getView().setModel(oJsonModel1, "oJsonModel");
						// }
						var oAdditionalForm = that.getView().byId("dispEditAdditionalInfoForm").destroyContent();
						if (columnsArr.length > 0) {
							var oController = that.getView().getController();
							var additionalInfo = that.getView().getModel("oJsonModel");

							var oAdditionalPanel = that.getView().byId("dispEditAdditionalInfoPanel");

							for (var j = 0; j < additionalInfo.oData.length; j++) {
								var oField = additionalInfo.oData[j].AddField;
								var oFieldLable = oField.split(":")[0];
								var oFieldValue = oField.split(":")[1];
								var oFieldtype = oField.split(":")[2];
								// var oFieldMand = oField.split(":")[3];
								// var has = "";
								// if (oFieldMand === "X") {
								// 	has = "*";
								// }
								// oFieldLable = has + "" + oFieldLable;
								// if (oFieldVal !== "Yes" && oFieldVal !== "No" && oFieldVal !== "") {
								oAdditionalForm.addContent(new sap.m.Label({
									text: oFieldLable,
									design: "Bold"
								}).addStyleClass("clsLabelColor"));

								if (oFieldtype.toLowerCase() === "state") {
									// var stateComboBox = that.stateComboBox;
									that.stateComboBox.setVisible(true);
									if (type === "Edit") {
										oAdditionalForm.addContent(stateComboBox);
										that.stateComboBox.setEnabled(true);
										that.stateComboBox.setValue(oFieldValue).setVisible(true);
									} else {
										oAdditionalForm.addContent(stateComboBox);
										that.stateComboBox.setEnabled(false);
										that.stateComboBox.setValue(oFieldValue);
									}
								} else if (oFieldtype.toLowerCase() === "date") {
									if (type === "Edit") {
										oAdditionalForm.addContent(new sap.m.DatePicker({
											value: oFieldValue,
											/*{
																							path: oFieldValue
																						},*/
											displayFormat: "MM/dd/yyyy",
											valueFormat: "yyyyMMdd",
											width: "100%",
											change: [oController.onAdditionalInfoChange, oController]
										}).addStyleClass("datePickerCls"));
									} else {

										oAdditionalForm.addContent(new sap.m.DatePicker({
											value: oFieldValue,
											// type: 
											/*{
																							path: oFieldValue
																						},*/
											enabled: false,
											displayFormat: "MM/dd/yyyy",
											valueFormat: "yyyyMMdd",
											width: "100%",
											change: [oController.onAdditionalInfoChange, oController]
										}).addStyleClass("datePickerCls"));
									}
								} else {
									if (type === "Edit") {

										var maxlen = 40;
										var ttype = "Text";
										if (oFieldtype === "Driver License" || oFieldValue === "DRIVER LICENSE") {
											maxlen = 15;
										}
										if (oFieldValue === "Numeric only" || oFieldValue === "NUMERIC ONLY") {
											ttype = "Number";
										}

										oAdditionalForm.addContent(new sap.m.Input({
											type: ttype,
											maxLength: maxlen,
											value: oFieldValue,
											/*{
																							path: oFieldValue
																						},*/
											width: "100%",
											change: [oController.onAdditionalInfoChange, oController]
										}));
									} else {
										oAdditionalForm.addContent(new sap.m.Input({
											value: oFieldValue,
											/*{
																							path: oFieldValue
																						},*/
											enabled: false,
											width: "100%",
											change: [oController.onAdditionalInfoChange, oController]
										}));
									}
								}
								// }
							}

							if (type === "Display") {
								that.byId("uploaderHbox").setVisible(false);
								that.byId("uploadAttachmentsTable").setVisible(true);
							} else {

								// var oHBox = new sap.m.HBox({});
								// var oVBox = new sap.m.VBox({});

								// oHBox.addItem(new sap.m.Label({
								// 	text: "Upload Documents :",
								// 	design: "Bold"
								// }).addStyleClass("clsLabelColor"));

								if (oData.Documents.toLowerCase() === "yes") {
									that.byId("uploaderHbox").setVisible(true);
									that.byId("uploadAttachmentsTable").setVisible(true);
									// oAdditionalForm.addContent(new sap.ui.unified.FileUploader({
									// 	id: "fileUploader",
									// 	change: [oController.onFileUpload, oController],
									// 	enabled: true
									// }));
									// oAdditionalForm.addContent(new sap.m.Label({
									// 	text: ""
									// }));
									// oAdditionalForm.addContent(
									// 	inlineTable
									// );
									// oHBox.addItem(new sap.ui.unified.FileUploader({
									// 	// id: "fileUploader",
									// 	change: [oController.onFileUpload, oController],
									// 	enabled: true
									// }).addStyleClass("sapUiTinyMarginBegin"));
									// oAdditionalPanel.addContent(oHBox);
									// oAdditionalPanel.addContent(
									// 	inlineTable
									// );
								} else {
									that.byId("uploaderHbox").setVisible(false);
									that.byId("uploadAttachmentsTable").setVisible(false);
									// oAdditionalForm.addContent(new sap.ui.unified.FileUploader({
									// 	enabled: false
									// }));
									// oHBox.addItem(new sap.ui.unified.FileUploader({
									// 	enabled: false
									// }).addStyleClass("sapUiTinyMarginBegin"));
								}

							}
						}
						if (type === "Display") {
							that.byId("uploaderHbox").setVisible(false);
							that.byId("uploadAttachmentsTable").setVisible(true);
						} else {
							if (oData.Documents.toLowerCase() === "yes") {
								that.byId("uploaderHbox").setVisible(true);
								that.byId("uploadAttachmentsTable").setVisible(true);
							}
						}
						// var oContent = that.byId("additionalInfoPanel").getContent();
						// var tableId = oContent[2].getId();
						that.byId("uploadAttachmentsTable").getModel("oAttachData").setData(that.attachArr);
						that.byId("uploadAttachmentsTable").getModel("oAttachData").refresh();

						/*that.byId("dispEditEmpNo").setText(empNo);
						that.byId("dispEditEnDate").setText(oEndDate);
						that.byId("dispEditQualInp").setText(qualID);
						that.byId("dispEditEffDate").setValue(effDate);
						that.byId("dispEditProfScale").setText(qualproficiency);
						that.byId("dispEditStDate").setText(oStartDate);
						that.byId("dispEditCraftType").setText(craft);*/

						// }
					},
					error: function (oResponse) {

						dialog.close();

						//-----------------------------------------------------------------------	
						// Displaying response body message.
						//-----------------------------------------------------------------------

						var errmsg;
						errmsg = JSON.parse(oResponse.responseText).error.message.value;

						sap.m.MessageBox.show(errmsg, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error"
						});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleInfo);
						oCreateDialog.setIcon("sap-icon://message-information");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: errmsg
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);
						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/
					}
				});
			}

		},

		onAttachTableUpdateFinished: function () {
			var that = this;
			var oItems = that.byId("uploadAttachmentsTable").getItems();
			for (var i = 0; i < oItems.length; i++) {
				if (that.type === "Display") {
					oItems[i].getAggregation("cells")[2].setVisible(false);
				} else {
					oItems[i].getAggregation("cells")[2].setVisible(true);
				}
			}
		},

		onAdditionalInfoChange: function (oEvt) {
			oEvt.getSource().setValueState("None");
			var that = this;
			var oFormContent = that.byId("dispEditAdditionalInfoForm").getContent();
			var emptyArr = [];
			var flag = "Yes";
			if (oFormContent.length > 0) {
				for (var i = 0; i < oFormContent.length; i++) {
					if (oFormContent[i].getMetadata().getElementName() === "sap.m.Input") {
						if (oFormContent[i].getProperty("value") !== "") {
							emptyArr.push(flag);
						}
					} else if (oFormContent[i].getMetadata().getElementName() === "sap.m.ComboBox") {
						if (oFormContent[i].getProperty("value") !== "") {
							emptyArr.push(flag);
						}
					} else if (oFormContent[i].getMetadata().getElementName() === "sap.m.DatePicker") {
						if (oFormContent[i].getProperty("value") !== "") {
							emptyArr.push(flag);
						}
					}
				}
			}

			if (that.byId("uploadAttachmentsTable").getVisible() === true) {
				var oDocsTable = that.byId("uploadAttachmentsTable").getItems();
				if (oDocsTable.length !== 0) {
					emptyArr.push(flag);
				}
			}

			if (emptyArr.length !== 0) {
				that.byId("dispEditSaveBtn").setEnabled(true);
			} else {
				that.byId("dispEditSaveBtn").setEnabled(true);
			}
		},

		onAfterRendering: function () {
			var that = this;
			titleError = that.getView().getModel("i18n").getProperty("titleError");
			close = that.getView().getModel("i18n").getProperty("close");
			//that.getView().byId("dispEditAdditionalInfoForm").destroy();
		},

		// ---------------------------------------- State Dropdown binding --------------------------------------

		stateDataFun: function () {
			var that = this;

			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/StateSearchHelpSet", {
				success: function (oData, Response) {
					var oStateModel = new sap.ui.model.json.JSONModel(oData);
					that.getView().setModel(oStateModel, "stateData");
				},
				error: function (oResponse) {

					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------

					var errmsg = JSON.parse(oResponse.responseText).error.message.value;

					sap.m.MessageBox.show(errmsg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error"
					});

					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleError);
					oCreateDialog.setIcon("sap-icon://message-error");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: errmsg
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);

					oCreateDialog.addButton(
						new sap.m.Button({
							text: close,
							press: function () {
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/

				}
			});
		},

		onFileUpload: function () {
			var that = this;
			//ediii
			that.byId("dispEditSaveBtn").setEnabled(true);
			/*	var oContent = that.byId("additionalInfoPanel").getContent();
				var uploaderId = oContent[1].getId();
				var tableId = oContent[2].getId();
				var fileupload = sap.ui.getCore().byId(uploaderId);
				var fileName = sap.ui.getCore().byId(uploaderId).getValue();*/
			var fileupload = that.byId("fileUploader");
			var fileName = fileupload.getValue();

			if (fileName === "") {
				sap.m.MessageToast.show("Please Select File");
			} else {

				// ============================================================================
				/*Getting Multiple Records From Table*/
				// ============================================================================

				var filedata;
				var file = jQuery.sap.domById(fileupload.getId() + "-fu").files[0];
				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function () {
					var result = reader.result;
					var res = result.split(";base64,");
					filedata = res[1];
					var fileDataObj = {};
					fileDataObj.DocName = fileName;
					fileDataObj.DocData = filedata;
					that.attachArr.push(fileDataObj);
					that.byId("uploadAttachmentsTable").getModel("oAttachData").setData(that.attachArr);
					that.onAdditionalInfoChange();
				};
				reader.onerror = function (error) {
					//console.log('Error: ', error);
				};
				that.byId("fileUploader").setValue("");
			}

		},

		onFileDownload: function (oEvent) {

			var that = this;
			var attachment = oEvent.getSource().getProperty("text");
			var pernr = that.byId("dispEditEmpNo").getText();

			var sUrl = this.getOwnerComponent().getModel().sServiceUrl;
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, false);
			oModel.read("/AdditionalDocumentsSet(Pernr='" + pernr + "',Qualification='" + that.qualId + "',DocName='" + attachment +
				"')/$value", null,
				null, true,
				function (oData, oResponse) {
					var pdfURL = oResponse.requestUri;
					that.download(pdfURL, attachment);
				},
				function (error) {
					sap.m.MessageToast.show("Failed");
				});

		},

		download: function (dataurl, Filename) {
			var a = document.createElement("a");
			a.href = dataurl;
			a.setAttribute("download", Filename);
			var b = document.createEvent("MouseEvents");
			b.initEvent("click", false, true);
			a.dispatchEvent(b);
			return false;
		},

		onFileDelete: function (oEvent) {

			var that = this;

			var oContent = that.byId("dispEditAdditionalInfoPanel").getContent();
			var tableId = oContent[2].getId();

			var oModelres = that.byId("uploadAttachmentsTable").getModel("oAttachData").getData();
			var path = parseInt(oEvent.getSource().getId().split("uploadAttachmentsTable-")[1]);
			oModelres.splice(path, "1");
			that.byId("uploadAttachmentsTable").getModel("oAttachData").refresh();

			var data = that.byId("uploadAttachmentsTable").getItems();
			if (data.length === 0) {
				that.byId("dispEditSaveBtn").setEnabled(true);
			} else {
				that.byId("dispEditSaveBtn").setEnabled(true);
			}
		},

		onCancel: function () {
			var that = this;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
			if (that.type === "Edit") {
				var yes = that.getView().getModel("i18n").getProperty("yes");
				var no = that.getView().getModel("i18n").getProperty("no");
				var titleConfirm = that.getView().getModel("i18n").getProperty("titleConfirm");

				sap.m.MessageBox.confirm("Unsaved data will be lost, are you sure you want to cancel?", {
					title: titleConfirm,
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {

							var emptyArr = [];
							var oFormData = that.getView().byId("dispEditAdditionalInfoForm");
							// oFormData.destroyContent();
							oFormData.removeAllContent();
							// var oPanelData = that.getView().byId("additionalInfoPanel");
							// oPanelData.destroyContent();
							that.byId("uploadAttachmentsTable").getModel("oAttachData").setData(emptyArr);
							that.byId("uploaderHbox").setVisible(false);
							that.byId("uploadAttachmentsTable").setVisible(false);

							oRouter.navTo("worklist");

						}
					}
				});

				/*var oCreateDialog = new sap.m.Dialog();
				oCreateDialog.setTitle(titleConfirm);
				oCreateDialog.setIcon("sap-icon://question-mark");
				oCreateDialog.addStyleClass("dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
				var oSimpleForm = new sap.ui.layout.form.SimpleForm({
					content: [
						new sap.m.Text({
							text: "Unsaved data will be lost, are you sure you want to cancel?"
						})
					]
				});
				oCreateDialog.addContent(oSimpleForm);
				oCreateDialog.addButton(
					new sap.m.Button({
						text: yes,
						press: function () {
							var emptyArr = [];
							var oFormData = that.getView().byId("dispEditAdditionalInfoForm");
							// oFormData.destroyContent();
							oFormData.removeAllContent();
							// var oPanelData = that.getView().byId("additionalInfoPanel");
							// oPanelData.destroyContent();
							that.byId("uploadAttachmentsTable").getModel("oAttachData").setData(emptyArr);
							that.byId("uploaderHbox").setVisible(false);
							that.byId("uploadAttachmentsTable").setVisible(false);

							oRouter.navTo("worklist");
							oCreateDialog.close();
						}
					}).addStyleClass("sapUiSizeCompact clsBtnColorYellowGreen")

				);

				oCreateDialog.addButton(
					new sap.m.Button({
						text: no,
						press: function () {
							oCreateDialog.close();
						}
					}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
				);
				oCreateDialog.open();*/

			} else {
				var emptyArr = [];
				var oFormData = that.getView().byId("dispEditAdditionalInfoForm");
				// oFormData.destroyContent();
				oFormData.removeAllContent();
				// var oPanelData = that.getView().byId("additionalInfoPanel");
				// oPanelData.destroyContent();
				that.byId("uploadAttachmentsTable").getModel("oAttachData").setData(emptyArr);
				that.byId("uploaderHbox").setVisible(false);
				that.byId("uploadAttachmentsTable").setVisible(false);
				oRouter.navTo("worklist");
			}

		},

		onSave: function () {

			var that = this;

			var titleSuccess = that.getView().getModel("i18n").getProperty("titleSuccess");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");

			var sDate = that.byId("dispEditStDate").getText();
			if (sDate !== "") {
				var oSDate = sDate.split("/");
				var startDate = oSDate[2] + "" + oSDate[0] + "" + oSDate[1];
			} else {
				startDate = "";
			}
			var eDate = that.byId("dispEditEnDate").getValue();
			if (eDate !== "") {
				var oEDate = eDate.split("/");
				var endDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
			} else {
				endDate = "";
			}

			var cols = that.columnsArray;
			var oAdditionalInfoData = that.byId("dispEditAdditionalInfoForm").getContent();
			// var additionalInfoArr = [];
			var additionalInfoObj = {};

			if (oAdditionalInfoData.length > 0) {
				var valdSave = 0;
				for (var i = 0; i < oAdditionalInfoData.length; i++) {
					if (oAdditionalInfoData[i].getMetadata().getElementName() === "sap.m.Label") {
						var oFieldName = oAdditionalInfoData[i].getProperty("text");
						if (oFieldName !== "Upload Documents") {
							if (cols[0] !== undefined) {
								var columnName1 = cols[0].AddField;
								var oField1 = columnName1.split(":")[0];
								// var oFieldMand = columnName1.split(":")[3];
								// var has = "";
								// if (oFieldMand === "X") {
								// 	has = "*";
								// }
								// oField1 = has + "" + oField1;
								if (oField1 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField1 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);

								}
							}
							if (cols[1] !== undefined) {
								var columnName2 = cols[1].AddField;
								var oField2 = columnName2.split(":")[0];
								if (oField2 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField2 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[2] !== undefined) {
								var columnName3 = cols[2].AddField;
								var oField3 = columnName3.split(":")[0];
								if (oField3 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField3 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[3] !== undefined) {
								var columnName4 = cols[3].AddField;
								var oField4 = columnName4.split(":")[0];
								if (oField4 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField4 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[4] !== undefined) {
								var columnName5 = cols[4].AddField;
								var oField5 = columnName5.split(":")[0];
								if (oField5 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField5 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[5] !== undefined) {
								var columnName6 = cols[5].AddField;
								var oField6 = columnName6.split(":")[0];
								if (oField6 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField6 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[6] !== undefined) {
								var columnName7 = cols[6].AddField;
								var oField7 = columnName7.split(":")[0];
								if (oField7 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField7 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[7] !== undefined) {
								var columnName8 = cols[7].AddField;
								var oField8 = columnName8.split(":")[0];
								if (oField8 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField8 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[8] !== undefined) {
								var columnName9 = cols[8].AddField;
								var oField9 = columnName9.split(":")[0];
								if (oField9 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField9 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[9] !== undefined) {
								var columnName10 = cols[9].AddField;
								var oField10 = columnName10.split(":")[0];
								if (oField10 === oFieldName) {
									if (oFieldName.charAt(0) === "*" && oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue() === "") {
										valdSave = 1;
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("Error");
									} else {
										oAdditionalInfoData[i].getParent().getAggregation("fields")[0].setValueState("None");
									}
									additionalInfoObj.AddField10 = oAdditionalInfoData[i].getParent().getAggregation("fields")[0].getValue();
									// additionalInfoArr.push(additionalInfoObj);
								}
							}

							// additionalInfoArr.push(additionalInfoObj);

						}

					}
					if (valdSave === 1) {
						sap.m.MessageToast.show("Please enter mandatory fields");
						return;
					}
					additionalInfoObj.QualGroup = that.craftType;
					additionalInfoObj.QualDesc = that.byId("dispEditQualInp").getText();
					additionalInfoObj.Qualification = that.qualId;
					additionalInfoObj.Pscale = that.byId("dispEditProfScale").getText();
					additionalInfoObj.Begda = startDate;
					additionalInfoObj.Endda = endDate;
					additionalInfoObj.Pernr = that.byId("dispEditEmpNo").getText();
					additionalInfoObj.Key = "D";

					var attachmentsArr = [];
					var itemsObject = {};
					// if (that.byId("uploadAttachmentsTable").getVisible() === true) {
					var oDocsData = that.byId("uploadAttachmentsTable").getItems();

					// itemsObject.Key = "D";
					// var additionalInfoArr = [];
					for (var j = 0; j < oDocsData.length; j++) {
						var attachmentsObj = {};
						// attachmentsObj.Key = "D";
						attachmentsObj.DocName = oDocsData[j].getAggregation("cells")[0].getText();
						attachmentsObj.Document = oDocsData[j].getAggregation("cells")[1].getValue();
						itemsObject = Object.assign(attachmentsObj, additionalInfoObj);
						attachmentsArr.push(itemsObject);
					}
					if (oDocsData.length === 0) {
						attachmentsArr.push(additionalInfoObj);
					}

				}

			} else {

				// if (oFieldName === "") {
				var oDocsData1 = that.byId("uploadAttachmentsTable").getItems();
				var attachmentsArr = [];
				// var itemsObject = {};
				// itemsObject.Key = "D";
				// var additionalInfoArr = [];
				var attachmentsObj1 = {};
				attachmentsObj1.QualGroup = that.craftType;
				attachmentsObj1.QualDesc = that.byId("dispEditQualInp").getText();
				attachmentsObj1.Qualification = that.qualId;
				attachmentsObj1.Pscale = that.byId("dispEditProfScale").getText();
				attachmentsObj1.Begda = startDate;
				attachmentsObj1.Endda = endDate;
				attachmentsObj1.Pernr = that.byId("dispEditEmpNo").getText();
				attachmentsObj1.Key = "D";
				for (var o = 0; o < oDocsData1.length; o++) {
					attachmentsObj1.DocName = oDocsData1[o].getAggregation("cells")[0].getText();
					attachmentsObj1.Document = oDocsData1[o].getAggregation("cells")[1].getValue();
					attachmentsArr.push(attachmentsObj1);
					// additionalInfoArr.push(additionalInfoObj);
				}
				if (oDocsData1.length === 0) {
					attachmentsArr.push(attachmentsObj1);
				}

			}

			// }

			// var sDate = that.byId("dispEditStDate").getText();
			// if (sDate !== "") {
			// 	var oSDate = sDate.split("/");
			// 	var startDate = oSDate[2] + "" + oSDate[0] + "" + oSDate[1];
			// } else {
			// 	startDate = "";
			// }
			// var eDate = that.byId("dispEditEnDate").getText();
			// if (eDate !== "") {
			// 	var oEDate = eDate.split("/");
			// 	var endDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
			// } else {
			// 	endDate = "";
			// }

			var oEntry = {};
			// oEntry.QualGroup = that.craftType;
			// oEntry.QualDesc = that.byId("dispEditQualInp").getText();
			oEntry.Qualification = that.qualId;
			// oEntry.Pscale = that.byId("dispEditProfScale").getText();
			// oEntry.Begda = startDate;
			// oEntry.Endda = endDate;
			oEntry.Pernr = that.byId("dispEditEmpNo").getText();
			// for (var k = 0; k < attachmentsArr.length; k++) {
			// 	attachmentsArr[k].QualGroup = that.craftType;
			// 	attachmentsArr[k].QualDesc = that.byId("dispEditQualInp").getText();
			// 	attachmentsArr[k].Pscale = that.byId("dispEditProfScale").getText();
			// 	attachmentsArr[k].Begda = startDate;
			// 	attachmentsArr[k].Endda = endDate;
			// }
			// if (attachmentsArr.length > 0) {
			// 	oEntry.CreateQualificationSet = attachmentsArr;
			// }
			oEntry.CreateQualificationSet = attachmentsArr;

			var oComponentData = that.getOwnerComponent().getComponentData().startupParameters;
			var dialog = new sap.m.BusyDialog({

			});

			dialog.open();
			var oModel = that.getOwnerComponent().getModel();
			oModel.create("/QualHeaderSet", oEntry, {
				success: function (oData, oResponse) {
					dialog.close();

					sap.m.MessageBox.show(
						"Created Successfully", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Information",
							onClose: function (sAction) {
								if (sAction === "OK") {

									var srvCal;
									if (this.srvResp === "Yes") {
										srvCal = "Yes";
									} else {
										srvCal = "No";
									}
									oComponentData.srvCal = [srvCal];
									sap.ui.core.UIComponent.getRouterFor(that).navTo("worklist");

								}
							}
						});

					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleSuccess);
					oCreateDialog.setIcon("sap-icon://message-success");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: "Created Successfully"
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);

					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {
								var srvCal;
								if (this.srvResp === "Yes") {
									srvCal = "Yes";
								} else {
									srvCal = "No";
								}
								oComponentData.srvCal = [srvCal];
								sap.ui.core.UIComponent.getRouterFor(that).navTo("worklist");
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/

				},
				error: function (oResponse) {
					dialog.close();
					that.srvResp = "Yes";

					//-----------------------------------------------------------------------	
					// Displaying response header message.
					//-----------------------------------------------------------------------

					var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;

					sap.m.MessageBox.show(
						oMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: titleInfo,
							onClose: function (sAction) {
								if (sAction === "OK") {

									var srvCal;
									if (this.srvResp === "Yes") {
										srvCal = "Yes";
									} else {
										srvCal = "No";
									}
									oComponentData.srvCal = [srvCal];
									sap.ui.core.UIComponent.getRouterFor(that).navTo("worklist");

								}
							}
						});

					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleInfo);
					oCreateDialog.setIcon("sap-icon://message-information");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: oMessage
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);
					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {
								var srvCal;
								if (this.srvResp === "Yes") {
									srvCal = "Yes";
								} else {
									srvCal = "No";
								}
								oComponentData.srvCal = [srvCal];
								sap.ui.core.UIComponent.getRouterFor(that).navTo("worklist");

								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/

				}
			});

		},

		onDelimit: function (oEvent) {
			var that = this;
			if (!that._qualValueDelimit) {
				that._qualValueDelimit = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.Delimit", that.getView()
					.getController());
				that.getView().addDependent(that._qualValueDelimit);
			}
			that._qualValueDelimit.open();

			that._qualValueDelimit.setEscapeHandler(function (o) {
				o.reject();
			});

			sap.ui.getCore().byId("delimitQual").setValue(that.qualId);
			sap.ui.getCore().byId("qualDelimtDate").setValue("");
		},

		onDelimiDateChange: function () {

			var that = this;
			var oStartDate = that.byId("dispEditStDate").getText();
			// if (stDate !== "") {
			// 	var oStartDate = stDate.substring(4, 6) + "/" + stDate.substring(6, 8) + "/" + stDate.substring(0, 4);
			// }
			var oEndDate = that.byId("dispEditEnDate").getValue();
			// if (enDate !== "") {
			// 	var oEndDate = enDate.substring(4, 6) + "/" + enDate.substring(6, 8) + "/" + enDate.substring(0, 4);
			// }
			var delimitDate = sap.ui.getCore().byId("qualDelimtDate").getValue();
			if (delimitDate !== "") {
				var oDelimitDate = delimitDate.substring(4, 6) + "/" + delimitDate.substring(6, 8) + "/" + delimitDate.substring(0, 4);
			}
			if ((new Date(oStartDate) <= new Date(oDelimitDate)) && (new Date(oEndDate) >= new Date(oDelimitDate))) {
				sap.ui.getCore().byId("qualDelimtDate").setValue(delimitDate);

			} else {
				sap.ui.getCore().byId("qualDelimtDate").setValue();
				sap.m.MessageToast.show("Please select the Delimit Date between" + oStartDate + " " + "and" + " " + oEndDate);
			}

		},

		onDelimitCancel: function () {
			var that = this;
			that._qualValueDelimit.close();
		},

		onUpdateDelimit: function () {
			var that = this;
			var titleSuccess = that.getView().getModel("i18n").getProperty("titleSuccess");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");

			var oDelimit = sap.ui.getCore().byId("qualDelimtDate").getValue();
			if (oDelimit !== "") {

				var sDate = that.byId("dispEditStDate").getText();
				if (sDate !== "") {
					var oSDate = sDate.split("/");
					var startDate = oSDate[2] + "" + oSDate[0] + "" + oSDate[1];
				} else {
					startDate = "";
				}
				/*var eDate = that.byId("dispEditEnDate").getText();
				if (eDate !== "") {
					var oEDate = eDate.split("/");
					var endDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
				} else {
					endDate = "";
				}*/

				var itemObj = {};

				itemObj.Qualification = that.qualId;
				itemObj.Begda = startDate;
				// itemObj.Endda = endDate;
				itemObj.Endda = oDelimit;
				itemObj.Pernr = that.byId("dispEditEmpNo").getText();
				itemObj.Key = "E";

				var oEntry = {};
				oEntry.Pernr = that.byId("dispEditEmpNo").getText();
				oEntry.Qualification = that.qualId;
				// oEntry.Key = "E";
				oEntry.CreateQualificationSet = itemObj;

				var oModel = that.getOwnerComponent().getModel();
				oModel.create("/QualHeaderSet", oEntry, {
					success: function (oData, oResponse) {

						sap.m.MessageBox.show(
							"Created Successfully", {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: "Information",
								onClose: function (sAction) {
									if (sAction === "OK") {
										that._qualValueDelimit.close();
									}
								}
							});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleSuccess);
						oCreateDialog.setIcon("sap-icon://message-success");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: "Created Successfully"
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);

						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
									that._qualValueDelimit.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/

					},
					error: function (oResponse) {

						//-----------------------------------------------------------------------	
						// Displaying response header message.
						//-----------------------------------------------------------------------

						var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;

						sap.m.MessageBox.show(
							oMessage, {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: titleInfo,
								onClose: function (sAction) {
									if (sAction === "OK") {
										that._qualValueDelimit.close();
									}
								}
							});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleInfo);
						oCreateDialog.setIcon("sap-icon://message-information");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: oMessage
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);
						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
									that._qualValueDelimit.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/

					}
				});

				// that._qualValueDelimit.close();
			} else {
				sap.m.MessageToast.show("Please select Delimit Date");
			}
		}

	});

});