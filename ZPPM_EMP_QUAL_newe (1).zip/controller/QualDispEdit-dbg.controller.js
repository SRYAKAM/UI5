// var inlineTable;
var titleError;
var close;
// var stateComboBox;
sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter",
	"sap/m/DatePicker"
], function (BaseController, JSONModel, History, formatter, DatePicker) {
	"use strict";
	var fileDataArr = [];

	return BaseController.extend("com.empqualassignment.Employee_Qual_Assignment.controller.QualDispEdit", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var that = this;
			that.getRouter().getRoute("QualDispEdit").attachPatternMatched(that._onObjectMatched, that);

		},

		_onObjectMatched: function (oEvent) {
			var that = this;

			that.srvResp = "No";
			// var oController = that.getView().getController();
			that.stateDataFun();
			/*var stateComboBox = new sap.m.ComboBox({
				id: "stateComboBox",
				width: "45%",
				change: [oController.onAdditionalInfoChange, oController]
			}).addStyleClass("comboBgCls");
			var oStateTemp = new sap.ui.core.ListItem({
				key: "{stateData>State}",
				text: "{stateData>State}"
			});

			stateComboBox.bindItems({
				path: "stateData>/results",
				template: oStateTemp
			});*/

			var emptyArr = [];
			var oEmptyModel = new sap.ui.model.json.JSONModel(emptyArr);
			var attachmentsTable = that.byId("uploadAttachmentsTable");
			attachmentsTable.setModel(oEmptyModel, "oAttachData");
			/*	var inlineTable = new sap.m.Table({
					// id: "uploadAttachmentsTable",
					columns: [new sap.m.Column({
							header: new sap.m.Label({
								text: "Attachment",
								design: "Bold"
							})
						}),
						new sap.m.Column({
							visible: false,
							header: new sap.m.Label({
								text: "Data"
							})
						}),
						new sap.m.Column({
							header: new sap.m.Label({
								text: ""
							})
						})
					]
				}).addStyleClass("clsTableHeader clsColumnHeader clsTableRows");
				inlineTable.bindItems("oAttachData>/", new sap.m.ColumnListItem({
					cells: [
						new sap.m.Link({
							text: "{oAttachData>DocName}",
							press: [oController.onFileDownload, oController]
						}),
						new sap.m.Input({
							value: "{oAttachData>DocData}"
						}),
						new sap.m.Button({
							icon: "sap-icon://delete",
							press: [oController.onFileDelete, oController]
						}).addStyleClass("clsBtnColorYellowRed")
					]
				}));*/
			// var oContent = that.byId("additionalInfoPanel").getContent();
			// var tableId = oContent[2].getId();
			// sap.ui.getCore().setModel(oEmptyModel, "oAttachData");
			//INLPAT
			var empNo = oEvent.getParameter("arguments").empNo;
			var qualID = oEvent.getParameter("arguments").qualId;
			that.qualId = qualID;
			var effDate = oEvent.getParameter("arguments").effDate;
			var oEffectiveDate = effDate.substring(4, 6) + "/" + effDate.substring(6, 8) + "/" + effDate.substring(0, 4);
			var craft = oEvent.getParameter("arguments").craft;
			var craftType;
			if (craft === "Engineering") {
				craftType = "TRACS - Engineering";
			} else if (craft === "Mechanical") {
				craftType = "TRACS - Mechanica";
			} else if (craft === "TCU") {
				craftType = "TRACS - TCU";
			}

			that.craftType = craftType;

			var qualDesc = oEvent.getParameter("arguments").qualDesc;
			var startDate = oEvent.getParameter("arguments").startDate;
			var oStartDate = startDate.substring(4, 6) + "/" + startDate.substring(6, 8) + "/" + startDate.substring(0, 4);
			var endDate = oEvent.getParameter("arguments").endDate;
			var oEndDate = endDate.substring(4, 6) + "/" + endDate.substring(6, 8) + "/" + endDate.substring(0, 4);
			var profScale = oEvent.getParameter("arguments").profScale;
			var type = oEvent.getParameter("arguments").type;
			that.type = type;

			that.byId("dispEditEmpNo").setText(empNo);
			that.byId("dispEditEnDate").setText(oEndDate);
			that.byId("dispEditQualInp").setText(qualDesc);
			that.byId("dispEditEffDate").setValue(effDate);
			that.byId("dispEditProfScale").setText(profScale);
			that.byId("dispEditStDate").setText(oStartDate);
			that.byId("dispEditCraftType").setText(craft);

			if (type === "Edit") {
				that.byId("dispEditSaveBtn").setVisible(true);
				that.byId("dispEditCancelBtn").setVisible(true);
				that.byId("dispEditDelimitBtn").setVisible(false);
				that.byId("dispEditAdditionalInfoPanel").setVisible(true);
			} else if (type === "Display") {
				that.byId("dispEditSaveBtn").setVisible(false);
				that.byId("dispEditCancelBtn").setVisible(true);
				that.byId("dispEditDelimitBtn").setVisible(false);
				that.byId("dispEditAdditionalInfoPanel").setVisible(true);
			} else if (type === "Delimit") {
				that.byId("dispEditSaveBtn").setVisible(false);
				that.byId("dispEditCancelBtn").setVisible(true);
				that.byId("dispEditDelimitBtn").setVisible(true);
				that.byId("dispEditAdditionalInfoPanel").setVisible(false);
			}

			if (type !== "Delimit") {

				var titleInfo = this.getView().getModel("i18n").getProperty("titleInfo");
				var ok = this.getView().getModel("i18n").getProperty("ok");

				//-----------------------------------------------------------------------	
				//Busy Indicator.
				//-----------------------------------------------------------------------

				var dialog = new sap.m.BusyDialog({

				});

				dialog.open();

				// that.defaultDate();

				var queryFil = [];
				var empNum = new sap.ui.model.Filter("Pernr", "EQ", empNo);
				var EffDate = new sap.ui.model.Filter("EffDate", "EQ", effDate);
				var Key = new sap.ui.model.Filter("Key", "EQ", "D");
				queryFil.push(empNum);
				queryFil.push(EffDate);
				queryFil.push(Key);

				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/EmpQualificationSet", {
					filters: queryFil,
					success: function (oData) {
						dialog.close();
						if (oData.results.length > 0) {

							that.attachArr = [];
							for (var i = 0; i < oData.results.length; i++) {
								// var columnsArr = [];
								// that.columnsArray = [];
								if (oData.results[i].Qualif === qualID) {

									var columnsArr = [];
									that.columnsArray = [];

									var columnsObj = {};
									var attachObj = {};

									var AddField1;
									if (oData.results[i].AddField1 !== "") {
										AddField1 = oData.results[i].AddField1;
										columnsObj.AddField1 = oData.results[i].AddField1;
									} else {
										AddField1 = oData.results[i].AddField1;
									}
									var AddField2;
									if (oData.results[i].AddField2 !== "") {
										AddField2 = oData.results[i].AddField2;
										columnsObj.AddField2 = oData.results[i].AddField2;
									} else {
										AddField2 = oData.results[i].AddField2;
									}
									var AddField3;
									if (oData.results[i].AddField3 !== "") {
										AddField3 = oData.results[i].AddField3;
										columnsObj.AddField3 = oData.results[i].AddField3;
									} else {
										AddField3 = oData.results[i].AddField3;
									}
									var AddField4;
									if (oData.results[i].AddField4 !== "") {
										AddField4 = oData.results[i].AddField4;
										columnsObj.AddField4 = oData.results[i].AddField4;
									} else {
										AddField4 = oData.results[i].AddField4;
									}
									var AddField5;
									if (oData.results[i].AddField5 !== "") {
										AddField5 = oData.results[i].AddField5;
										columnsObj.AddField5 = oData.results[i].AddField5;
									} else {
										AddField5 = oData.results[i].AddField5;
									}
									var AddField6;
									if (oData.results[i].AddField6 !== "") {
										AddField6 = oData.results[i].AddField6;
										columnsObj.AddField6 = oData.results[i].AddField6;
									} else {
										AddField6 = oData.results[i].AddField6;
									}
									var AddField7;
									if (oData.results[i].AddField7 !== "") {
										AddField7 = oData.results[i].AddField7;
										columnsObj.AddField7 = oData.results[i].AddField7;
									} else {
										AddField7 = oData.results[i].AddField7;
									}
									var AddField8;
									if (oData.results[i].AddField8 !== "") {
										AddField8 = oData.results[i].AddField8;
										columnsObj.AddField8 = oData.results[i].AddField8;
									} else {
										AddField8 = oData.results[i].AddField8;
									}
									var AddField9;
									if (oData.results[i].AddField9 !== "") {
										AddField9 = oData.results[i].AddField9;
										columnsObj.AddField9 = oData.results[i].AddField9;
									} else {
										AddField9 = oData.results[i].AddField9;
									}
									var AddField10;
									if (oData.results[i].AddField10 !== "") {
										AddField10 = oData.results[i].AddField10;
										columnsObj.AddField10 = oData.results[i].AddField10;
									} else {
										AddField10 = oData.results[i].AddField10;
									}

									that.columnsArray.push(columnsObj);

									if (AddField1 !== "") {
										columnsArr.push(AddField1);
									}
									if (AddField2 !== "") {
										columnsArr.push(AddField2);
									}
									if (AddField3 !== "") {
										columnsArr.push(AddField3);
									}
									if (AddField4 !== "") {
										columnsArr.push(AddField4);
									}
									if (AddField5 !== "") {
										columnsArr.push(AddField5);
									}
									if (AddField6 !== "") {
										columnsArr.push(AddField6);
									}
									if (AddField7 !== "") {
										columnsArr.push(AddField7);
									}
									if (AddField8 !== "") {
										columnsArr.push(AddField8);
									}
									if (AddField9 !== "") {
										columnsArr.push(AddField9);
									}
									if (AddField10 !== "") {
										columnsArr.push(AddField10);
									}

									if (oData.results[i].DocName !== "") {
										attachObj.DocName = oData.results[i].DocName;
										attachObj.DocData = oData.results[i].DocData;

										that.attachArr.push(attachObj);
									}

								}
							}

							var oJsonModel = new JSONModel();
							oJsonModel.setData(columnsArr);
							that.getView().setModel(oJsonModel, "oJsonModel");
							// }

							if (AddField1 !== "" || AddField2 !== "" || AddField3 !== "" || AddField4 !== "" || AddField5 !== "" || AddField6 !== "" ||
								AddField7 !== "" || AddField8 !== "" || AddField9 !== "" || AddField10 !== "") {
								var oController = that.getView().getController();
								var additionalInfo = that.getView().getModel("oJsonModel");
								var oAdditionalForm = that.getView().byId("dispEditAdditionalInfoForm");
								var oAdditionalPanel = that.getView().byId("dispEditAdditionalInfoPanel");

								for (var j = 0; j < additionalInfo.oData.length; j++) {
									var oField = additionalInfo.oData[j];
									var oFieldLable = oField.split(":")[0];
									var oFieldValue = oField.split(":")[1];
									// if (oFieldVal !== "Yes" && oFieldVal !== "No" && oFieldVal !== "") {
									oAdditionalForm.addContent(new sap.m.Label({
										text: oFieldLable,
										design: "Bold"
									}).addStyleClass("clsLabelColor"));

									if (oFieldLable === "State" || oFieldLable === "STATE") {
										var stateComboBox = that.byId("stateComboBox");
										that.byId("stateComboBox").setVisible(true);
										if (type === "Edit") {
											oAdditionalForm.addContent(stateComboBox);
											that.byId("stateComboBox").setEnabled(true);
											that.byId("stateComboBox").setValue(oFieldValue);
										} else {
											oAdditionalForm.addContent(stateComboBox);
											that.byId("stateComboBox").setEnabled(false);
											that.byId("stateComboBox").setValue(oFieldValue);
										}
									} else if (oFieldLable.includes("DATE")) {
										if (type === "Edit") {
											oAdditionalForm.addContent(new sap.m.DatePicker({
												value: oFieldValue,
												/*{
																								path: oFieldValue
																							},*/
												displayFormat: "MM/dd/yyyy",
												valueFormat: "yyyyMMdd",
												width: "100%",
												change: [oController.onAdditionalInfoChange, oController]
											}).addStyleClass("inpBaseBg inpIconColor"));
										} else {
											oAdditionalForm.addContent(new sap.m.DatePicker({
												value: oFieldValue,
												/*{
																								path: oFieldValue
																							},*/
												enabled: false,
												displayFormat: "MM/dd/yyyy",
												valueFormat: "yyyyMMdd",
												width: "100%",
												change: [oController.onAdditionalInfoChange, oController]
											}).addStyleClass("inpBaseBg inpIconColor"));
										}
									} else {
										if (type === "Edit") {
											oAdditionalForm.addContent(new sap.m.Input({
												value: oFieldValue,
												/*{
																								path: oFieldValue
																							},*/
												width: "100%",
												change: [oController.onAdditionalInfoChange, oController]
											}));
										} else {
											oAdditionalForm.addContent(new sap.m.Input({
												value: oFieldValue,
												/*{
																								path: oFieldValue
																							},*/
												enabled: false,
												width: "100%",
												change: [oController.onAdditionalInfoChange, oController]
											}));
										}
									}
									// }
								}

								if (type === "Display") {
									that.byId("uploaderHbox").setVisible(false);
									that.byId("uploadAttachmentsTable").setVisible(true);
								} else {

									// var oHBox = new sap.m.HBox({});
									// var oVBox = new sap.m.VBox({});

									// oHBox.addItem(new sap.m.Label({
									// 	text: "Upload Documents :",
									// 	design: "Bold"
									// }).addStyleClass("clsLabelColor"));
									if (that.attachArr.length !== 0) {
										that.byId("uploaderHbox").setVisible(true);
										that.byId("uploadAttachmentsTable").setVisible(true);
										// oAdditionalForm.addContent(new sap.ui.unified.FileUploader({
										// 	id: "fileUploader",
										// 	change: [oController.onFileUpload, oController],
										// 	enabled: true
										// }));
										// oAdditionalForm.addContent(new sap.m.Label({
										// 	text: ""
										// }));
										// oAdditionalForm.addContent(
										// 	inlineTable
										// );
										// oHBox.addItem(new sap.ui.unified.FileUploader({
										// 	// id: "fileUploader",
										// 	change: [oController.onFileUpload, oController],
										// 	enabled: true
										// }).addStyleClass("sapUiTinyMarginBegin"));
										// oAdditionalPanel.addContent(oHBox);
										// oAdditionalPanel.addContent(
										// 	inlineTable
										// );
									} else {
										that.byId("uploaderHbox").setVisible(false);
										that.byId("uploadAttachmentsTable").setVisible(false);
										// oAdditionalForm.addContent(new sap.ui.unified.FileUploader({
										// 	enabled: false
										// }));
										// oHBox.addItem(new sap.ui.unified.FileUploader({
										// 	enabled: false
										// }).addStyleClass("sapUiTinyMarginBegin"));
									}

								}
							}

							// var oContent = that.byId("additionalInfoPanel").getContent();
							// var tableId = oContent[2].getId();
							that.byId("uploadAttachmentsTable").getModel("oAttachData").setData(that.attachArr);
							that.byId("uploadAttachmentsTable").getModel("oAttachData").refresh();

							/*that.byId("dispEditEmpNo").setText(empNo);
							that.byId("dispEditEnDate").setText(oEndDate);
							that.byId("dispEditQualInp").setText(qualID);
							that.byId("dispEditEffDate").setValue(effDate);
							that.byId("dispEditProfScale").setText(qualproficiency);
							that.byId("dispEditStDate").setText(oStartDate);
							that.byId("dispEditCraftType").setText(craft);*/

						}
					},
					error: function (oResponse) {

						dialog.close();

						//-----------------------------------------------------------------------	
						// Displaying response body message.
						//-----------------------------------------------------------------------

						var errmsg;
						errmsg = JSON.parse(oResponse.responseText).error.message.value;

						var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleInfo);
						oCreateDialog.setIcon("sap-icon://message-information");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: errmsg
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);
						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();
					}
				});
			}

		},

		onAttachTableUpdateFinished: function () {
			var that = this;
			var oItems = that.byId("uploadAttachmentsTable").getItems();
			for (var i = 0; i < oItems.length; i++) {
				if (that.type === "Display") {
					oItems[i].getAggregation("cells")[2].setVisible(false);
				} else {
					oItems[i].getAggregation("cells")[2].setVisible(true);
				}
			}
		},

		onAdditionalInfoChange: function () {
			var that = this;
			var oFormContent = that.byId("dispEditAdditionalInfoForm").getContent();
			var emptyArr = [];
			var flag = "Yes";
			if (oFormContent.length > 0) {
				for (var i = 0; i < oFormContent.length; i++) {
					if (oFormContent[i].getMetadata().getElementName() === "sap.m.Input") {
						if (oFormContent[i].getProperty("value") !== "") {
							emptyArr.push(flag);
						}
					} else if (oFormContent[i].getMetadata().getElementName() === "sap.m.ComboBox") {
						if (oFormContent[i].getProperty("value") !== "") {
							emptyArr.push(flag);
						}
					} else if (oFormContent[i].getMetadata().getElementName() === "sap.m.DatePicker") {
						if (oFormContent[i].getProperty("value") !== "") {
							emptyArr.push(flag);
						}
					}
				}
			}

			if (that.byId("uploadAttachmentsTable").getVisible() === true) {
				var oDocsTable = that.byId("uploadAttachmentsTable").getItems();
				if (oDocsTable.length !== 0) {
					emptyArr.push(flag);
				}
			}

			if (emptyArr.length !== 0) {
				that.byId("dispEditSaveBtn").setEnabled(false);
			} else {
				that.byId("dispEditSaveBtn").setEnabled(true);
			}
		},

		onAfterRendering: function () {
			var that = this;
			titleError = that.getView().getModel("i18n").getProperty("titleError");
			close = that.getView().getModel("i18n").getProperty("close");
		},

		// ---------------------------------------- State Dropdown binding --------------------------------------

		stateDataFun: function () {
			var that = this;

			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/StateSearchHelpSet", {
				success: function (oData, Response) {
					var oStateModel = new sap.ui.model.json.JSONModel(oData);
					that.getView().setModel(oStateModel, "stateData");
				},
				error: function (oResponse) {

					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------

					var errmsg = JSON.parse(oResponse.responseText).error.message.value;

					var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleError);
					oCreateDialog.setIcon("sap-icon://message-error");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: errmsg
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);

					oCreateDialog.addButton(
						new sap.m.Button({
							text: close,
							press: function () {
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();

				}
			});
		},

		onFileUpload: function () {
			var that = this;

			/*	var oContent = that.byId("additionalInfoPanel").getContent();
				var uploaderId = oContent[1].getId();
				var tableId = oContent[2].getId();
				var fileupload = sap.ui.getCore().byId(uploaderId);
				var fileName = sap.ui.getCore().byId(uploaderId).getValue();*/
			var fileupload = that.byId("fileUploader");
			var fileName = fileupload.getValue();

			if (fileName === "") {
				sap.m.MessageToast.show("Please Select File");
			} else {

				// ============================================================================
				/*Getting Multiple Records From Table*/
				// ============================================================================

				var filedata;
				var file = jQuery.sap.domById(fileupload.getId() + "-fu").files[0];
				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function () {
					var result = reader.result;
					var res = result.split(";base64,");
					filedata = res[1];
					var fileDataObj = {};
					fileDataObj.DocName = fileName;
					fileDataObj.DocData = filedata;
					that.attachArr.push(fileDataObj);
					that.byId("uploadAttachmentsTable").getModel("oAttachData").setData(that.attachArr);
					that.onAdditionalInfoChange();
				};
				reader.onerror = function (error) {
					console.log('Error: ', error);
				};
				that.byId("fileUploader").setValue("");
			}

		},

		onFileDownload: function (oEvent) {

			var that = this;
			var attachment = oEvent.getSource().getProperty("text");
			var pernr = that.byId("dispEditEmpNo").getText();

			var sUrl = this.getOwnerComponent().getModel().sServiceUrl;
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, false);
			oModel.read("/AdditionalDocumentsSet(Pernr='" + pernr + "',Qualification='" + that.qualId + "',DocName='" + attachment +
				"')/$value", null,
				null, true,
				function (oData, oResponse) {
					var pdfURL = oResponse.requestUri;
					that.download(pdfURL, attachment);
				},
				function (error) {
					sap.m.MessageToast.show("Failed");
				});

		},

		download: function (dataurl, Filename) {
			var a = document.createElement("a");
			a.href = dataurl;
			a.setAttribute("download", Filename);
			var b = document.createEvent("MouseEvents");
			b.initEvent("click", false, true);
			a.dispatchEvent(b);
			return false;
		},

		onFileDelete: function (oEvent) {

			var that = this;

			var oContent = that.byId("dispEditAdditionalInfoPanel").getContent();
			var tableId = oContent[2].getId();

			var oModelres = that.byId("uploadAttachmentsTable").getModel("oAttachData").getData();
			var path = parseInt(oEvent.getSource().getId().split("uploadAttachmentsTable-")[1]);
			oModelres.splice(path, "1");
			that.byId("uploadAttachmentsTable").getModel("oAttachData").refresh();

			var data = that.byId("uploadAttachmentsTable").getItems();
			if (data.length === 0) {
				that.byId("dispEditSaveBtn").setEnabled(false);
			} else {
				that.byId("dispEditSaveBtn").setEnabled(true);
			}
		},

		onCancel: function () {
			var that = this;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
			if (that.type === "Edit") {
				var yes = that.getView().getModel("i18n").getProperty("yes");
				var no = that.getView().getModel("i18n").getProperty("no");
				var titleConfirm = that.getView().getModel("i18n").getProperty("titleConfirm");

				var oCreateDialog = new sap.m.Dialog();
				oCreateDialog.setTitle(titleConfirm);
				oCreateDialog.setIcon("sap-icon://question-mark");
				oCreateDialog.addStyleClass("dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
				var oSimpleForm = new sap.ui.layout.form.SimpleForm({
					content: [
						new sap.m.Text({
							text: "Unsaved data will be lost, are you sure you want to cancel?"
						})
					]
				});
				oCreateDialog.addContent(oSimpleForm);
				oCreateDialog.addButton(
					new sap.m.Button({
						text: yes,
						press: function () {
							var emptyArr = [];
							var oFormData = that.getView().byId("dispEditAdditionalInfoForm");
							// oFormData.destroyContent();
							oFormData.removeAllContent();
							// var oPanelData = that.getView().byId("additionalInfoPanel");
							// oPanelData.destroyContent();
							that.byId("uploadAttachmentsTable").getModel("oAttachData").setData(emptyArr);
							that.byId("uploaderHbox").setVisible(false);
							that.byId("uploadAttachmentsTable").setVisible(false);

							oRouter.navTo("worklist");
							oCreateDialog.close();
						}
					}).addStyleClass("sapUiSizeCompact clsBtnColorYellowGreen")

				);

				oCreateDialog.addButton(
					new sap.m.Button({
						text: no,
						press: function () {
							oCreateDialog.close();
						}
					}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
				);
				oCreateDialog.open();

			} else {
				var emptyArr = [];
				var oFormData = that.getView().byId("dispEditAdditionalInfoForm");
				// oFormData.destroyContent();
				oFormData.removeAllContent();
				// var oPanelData = that.getView().byId("additionalInfoPanel");
				// oPanelData.destroyContent();
				that.byId("uploadAttachmentsTable").getModel("oAttachData").setData(emptyArr);
				that.byId("uploaderHbox").setVisible(false);
				that.byId("uploadAttachmentsTable").setVisible(false);
				oRouter.navTo("worklist");
			}

		},

		onSave: function () {

			var that = this;

			var titleSuccess = that.getView().getModel("i18n").getProperty("titleSuccess");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");

			var sDate = that.byId("dispEditStDate").getText();
			if (sDate !== "") {
				var oSDate = sDate.split("/");
				var startDate = oSDate[2] + "" + oSDate[0] + "" + oSDate[1];
			} else {
				startDate = "";
			}
			var eDate = that.byId("dispEditEnDate").getText();
			if (eDate !== "") {
				var oEDate = eDate.split("/");
				var endDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
			} else {
				endDate = "";
			}

			var cols = that.columnsArray;
			var oAdditionalInfoData = that.byId("dispEditAdditionalInfoForm").getContent();
			// var additionalInfoArr = [];
			var additionalInfoObj = {};

			if (oAdditionalInfoData.length > 0) {
				for (var i = 0; i < oAdditionalInfoData.length; i++) {
					if (oAdditionalInfoData[i].getMetadata().getElementName() === "sap.m.Label") {
						var oFieldName = oAdditionalInfoData[i].getProperty("text");
						if (oFieldName !== "Upload Documents") {
							if (cols[0].AddField1 !== undefined) {
								var columnName1 = cols[0].AddField1;
								var oField1 = columnName1.split(":")[0];
								if (oField1 === oFieldName) {
									additionalInfoObj.AddField1 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);

								}
							}
							if (cols[0].AddField2 !== undefined) {
								var columnName2 = cols[0].AddField2;
								var oField2 = columnName2.split(":")[0];
								if (oField2 === oFieldName) {
									additionalInfoObj.AddField2 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField3 !== undefined) {
								var columnName3 = cols[0].AddField3;
								var oField3 = columnName3.split(":")[0];
								if (oField3 === oFieldName) {
									additionalInfoObj.AddField3 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField4 !== undefined) {
								var columnName4 = cols[0].AddField4;
								var oField4 = columnName4.split(":")[0];
								if (oField4 === oFieldName) {
									additionalInfoObj.AddField4 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField5 !== undefined) {
								var columnName5 = cols[0].AddField5;
								var oField5 = columnName5.split(":")[0];
								if (oField5 === oFieldName) {
									additionalInfoObj.AddField5 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField6 !== undefined) {
								var columnName6 = cols[0].AddField6;
								var oField6 = columnName6.split(":")[0];
								if (oField6 === oFieldName) {
									additionalInfoObj.AddField6 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField7 !== undefined) {
								var columnName7 = cols[0].AddField7;
								var oField7 = columnName7.split(":")[0];
								if (oField7 === oFieldName) {
									additionalInfoObj.AddField7 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField8 !== undefined) {
								var columnName8 = cols[0].AddField8;
								var oField8 = columnName8.split(":")[0];
								if (oField8 === oFieldName) {
									additionalInfoObj.AddField8 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField9 !== undefined) {
								var columnName9 = cols[0].AddField9;
								var oField9 = columnName9.split(":")[0];
								if (oField9 === oFieldName) {
									additionalInfoObj.AddField9 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField10 !== undefined) {
								var columnName10 = cols[0].AddField10;
								var oField10 = columnName10.split(":")[0];
								if (oField10 === oFieldName) {
									additionalInfoObj.AddField10 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}

							// additionalInfoArr.push(additionalInfoObj);

						}

					}

					additionalInfoObj.QualGroup = that.craftType;
					additionalInfoObj.QualDesc = that.byId("dispEditQualInp").getText();
					additionalInfoObj.Qualification = that.qualId;
					additionalInfoObj.Pscale = that.byId("dispEditProfScale").getText();
					additionalInfoObj.Begda = startDate;
					additionalInfoObj.Endda = endDate;
					additionalInfoObj.Pernr = that.byId("dispEditEmpNo").getText();
					additionalInfoObj.Key = "D";

					var attachmentsArr = [];
					var itemsObject = {};
					if (that.byId("uploadAttachmentsTable").getVisible() === true) {
						var oDocsData = that.byId("uploadAttachmentsTable").getItems();

						// itemsObject.Key = "D";
						// var additionalInfoArr = [];
						for (var j = 0; j < oDocsData.length; j++) {
							var attachmentsObj = {};
							// attachmentsObj.Key = "D";
							attachmentsObj.DocName = oDocsData[j].getAggregation("cells")[0].getText();
							attachmentsObj.Document = oDocsData[j].getAggregation("cells")[1].getValue();
							itemsObject = Object.assign(attachmentsObj, additionalInfoObj);
							attachmentsArr.push(itemsObject);
							// additionalInfoArr.push(additionalInfoObj);
						}

					} else {
						attachmentsArr.push(additionalInfoObj);
					}

				}

			} else {

				// if (oFieldName === "") {
				var oDocsData1 = that.byId("uploadAttachmentsTable").getItems();
				// var attachmentsArr = [];
				// var itemsObject = {};
				// itemsObject.Key = "D";
				// var additionalInfoArr = [];
				for (var o = 0; o < oDocsData1.length; o++) {
					var attachmentsObj1 = {};

					attachmentsObj1.QualGroup = that.craftType;
					attachmentsObj1.QualDesc = that.byId("dispEditQualInp").getText();
					attachmentsObj1.Qualification = that.qualId;
					attachmentsObj1.Pscale = that.byId("dispEditProfScale").getText();
					attachmentsObj1.Begda = startDate;
					attachmentsObj1.Endda = endDate;
					attachmentsObj1.Pernr = that.byId("dispEditEmpNo").getText();
					attachmentsObj1.Key = "D";

					attachmentsObj1.DocName = oDocsData1[o].getAggregation("cells")[0].getText();
					attachmentsObj1.Document = oDocsData1[o].getAggregation("cells")[1].getValue();
					attachmentsArr.push(attachmentsObj1);
					// additionalInfoArr.push(additionalInfoObj);
				}

			}

			// }

			// var sDate = that.byId("dispEditStDate").getText();
			// if (sDate !== "") {
			// 	var oSDate = sDate.split("/");
			// 	var startDate = oSDate[2] + "" + oSDate[0] + "" + oSDate[1];
			// } else {
			// 	startDate = "";
			// }
			// var eDate = that.byId("dispEditEnDate").getText();
			// if (eDate !== "") {
			// 	var oEDate = eDate.split("/");
			// 	var endDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
			// } else {
			// 	endDate = "";
			// }

			var oEntry = {};
			// oEntry.QualGroup = that.craftType;
			// oEntry.QualDesc = that.byId("dispEditQualInp").getText();
			oEntry.Qualification = that.qualId;
			// oEntry.Pscale = that.byId("dispEditProfScale").getText();
			// oEntry.Begda = startDate;
			// oEntry.Endda = endDate;
			oEntry.Pernr = that.byId("dispEditEmpNo").getText();
			// for (var k = 0; k < attachmentsArr.length; k++) {
			// 	attachmentsArr[k].QualGroup = that.craftType;
			// 	attachmentsArr[k].QualDesc = that.byId("dispEditQualInp").getText();
			// 	attachmentsArr[k].Pscale = that.byId("dispEditProfScale").getText();
			// 	attachmentsArr[k].Begda = startDate;
			// 	attachmentsArr[k].Endda = endDate;
			// }
			// if (attachmentsArr.length > 0) {
			// 	oEntry.CreateQualificationSet = attachmentsArr;
			// }
			oEntry.CreateQualificationSet = attachmentsArr;

			var oComponentData = that.getOwnerComponent().getComponentData().startupParameters;

			var oModel = that.getOwnerComponent().getModel();
			oModel.create("/QualHeaderSet", oEntry, {
				success: function (oData, oResponse) {

					var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleSuccess);
					oCreateDialog.setIcon("sap-icon://message-success");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: "Created Successfully"
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);

					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();

				},
				error: function (oResponse) {

					that.srvResp = "Yes";

					//-----------------------------------------------------------------------	
					// Displaying response header message.
					//-----------------------------------------------------------------------

					var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;

					var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleInfo);
					oCreateDialog.setIcon("sap-icon://message-information");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: oMessage
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);
					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {
								var srvCal;
								if (this.srvResp === "Yes") {
									srvCal = "Yes";
								} else {
									srvCal = "No";
								}
								oComponentData.srvCal = [srvCal];
								sap.ui.core.UIComponent.getRouterFor(that).navTo("worklist");

								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();

				}
			});

		},

		onDelimit: function (oEvent) {
			var that = this;
			if (!that._qualValueDelimit) {
				that._qualValueDelimit = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.Delimit", that.getView()
					.getController());
				that.getView().addDependent(that._qualValueDelimit);
			}
			that._qualValueDelimit.open();
			sap.ui.getCore().byId("delimitQual").setValue(that.qualId);
			sap.ui.getCore().byId("qualDelimtDate").setValue("");
		},

		onDelimiDateChange: function () {

			var that = this;
			var oStartDate = that.byId("dispEditStDate").getText();
			// if (stDate !== "") {
			// 	var oStartDate = stDate.substring(4, 6) + "/" + stDate.substring(6, 8) + "/" + stDate.substring(0, 4);
			// }
			var oEndDate = that.byId("dispEditEnDate").getText();
			// if (enDate !== "") {
			// 	var oEndDate = enDate.substring(4, 6) + "/" + enDate.substring(6, 8) + "/" + enDate.substring(0, 4);
			// }
			var delimitDate = sap.ui.getCore().byId("qualDelimtDate").getValue();
			if (delimitDate !== "") {
				var oDelimitDate = delimitDate.substring(4, 6) + "/" + delimitDate.substring(6, 8) + "/" + delimitDate.substring(0, 4);
			}
			if ((new Date(oStartDate) <= new Date(oDelimitDate)) && (new Date(oEndDate) >= new Date(oDelimitDate))) {
				sap.ui.getCore().byId("qualDelimtDate").setValue(delimitDate);

			} else {
				sap.ui.getCore().byId("qualDelimtDate").setValue();
				sap.m.MessageToast.show("Please select the Delimit Date between" + oStartDate + " " + "and" + " " + oEndDate);
			}

		},

		onDelimitCancel: function () {
			var that = this;
			that._qualValueDelimit.close();
		},

		onUpdateDelimit: function () {
			var that = this;
			var titleSuccess = that.getView().getModel("i18n").getProperty("titleSuccess");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");

			var oDelimit = sap.ui.getCore().byId("qualDelimtDate").getValue();
			if (oDelimit !== "") {

				var sDate = that.byId("dispEditStDate").getText();
				if (sDate !== "") {
					var oSDate = sDate.split("/");
					var startDate = oSDate[2] + "" + oSDate[0] + "" + oSDate[1];
				} else {
					startDate = "";
				}
				/*var eDate = that.byId("dispEditEnDate").getText();
				if (eDate !== "") {
					var oEDate = eDate.split("/");
					var endDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
				} else {
					endDate = "";
				}*/

				var itemObj = {};

				itemObj.Qualification = that.qualId;
				itemObj.Begda = startDate;
				// itemObj.Endda = endDate;
				itemObj.Endda = oDelimit;
				itemObj.Pernr = that.byId("dispEditEmpNo").getText();
				itemObj.Key = "E";

				var oEntry = {};
				oEntry.Pernr = that.byId("dispEditEmpNo").getText();
				oEntry.Qualification = that.qualId;
				// oEntry.Key = "E";
				oEntry.CreateQualificationSet = itemObj;

				var oModel = that.getOwnerComponent().getModel();
				oModel.create("/QualHeaderSet", oEntry, {
					success: function (oData, oResponse) {

						var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleSuccess);
						oCreateDialog.setIcon("sap-icon://message-success");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: "Created Successfully"
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);

						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
									that._qualValueDelimit.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();

					},
					error: function (oResponse) {

						//-----------------------------------------------------------------------	
						// Displaying response header message.
						//-----------------------------------------------------------------------

						var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;

						var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleInfo);
						oCreateDialog.setIcon("sap-icon://message-information");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: oMessage
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);
						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
									that._qualValueDelimit.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();

					}
				});

				// that._qualValueDelimit.close();
			} else {
				sap.m.MessageToast.show("Please select Delimit Date");
			}
		}

	});

});