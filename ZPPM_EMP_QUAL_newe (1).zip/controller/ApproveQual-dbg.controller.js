sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter"
], function (BaseController, JSONModel, History, formatter) {
	"use strict";

	return BaseController.extend("com.empqualassignment.Employee_Qual_Assignment.controller.ApproveQual", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {

			this.getRouter().getRoute("ApproveQual").attachPatternMatched(this._onObjectMatched3, this);

		},

		_onObjectMatched3: function (oEvent) {
			var that = this;
			var oContext = oEvent.getParameter("arguments");
			that.arObject = oContext;
			that.QualId = oContext.QualId;
			that.timeStamp = oContext.Timestamp;
			that.subDate = oContext.SubDate;
			that.empId = oContext.EmpId;
			var oForm = that.byId("reqQualFormId");
			var oController = that.getView().getController();
			var oFormModel = new JSONModel(oContext);
			oForm.setModel(oFormModel);
			oForm.bindElement({
				path: "/"
			});
			var addInfoModel = new JSONModel();
			var oModel = that.getOwnerComponent().getModel("oDataSrv");
			oModel.read("/QualAddHeaderSet(QualId='" + that.QualId + "',SubDate='" + that.subDate + "',EmpId='" + that.empId +
				"',Timestamp='" + that.timeStamp + "')?$expand=QualDetailsNavi,QualDocNavi", {
					async: false,
					success: function (oData) {
						addInfoModel.setData(oData.QualDocNavi);
						that.getView().setModel(addInfoModel, "addInfoModel");
						//INLPAT
						if (oData.QualDetailsNavi.results.length > 0) {
							var oPanel = that.byId("qualReqAdditionalFormId");
							oPanel.setVisible(true);
							oPanel.destroyContent();
							var data = oData.QualDetailsNavi.results;
							var startDate = data[0].Begda;
							var endDate = data[0].Endda;
							that.byId("StartDateId").setValue(startDate);
							that.byId("EndDateId").setValue(endDate);
							var title = new sap.ui.core.Title({});
							oPanel.addContent(title);
							for (var i = 0; i < data.length; i++) {
								var column = data[i].Label;
								var value = data[i].Value;
								var leng = Number(data[i].Length);
								var dataType = data[i].Type;
								if (dataType === "CHAR") {
									dataType = "Text";
								}
								if (dataType === "DATE") {
									var oDatePic = new sap.m.DatePicker({
										value: value,
										width: "80%",
										enabled: false,
										valueFormat: "yyyyMMdd",
										displayFormat: "MM/dd/yyyy",
										placeholder: "MM/DD/YYYY",
										change: function (evt1) {
											if (evt1.getSource().getValue().trim().length > 0) {
												evt1.getSource().setValueState("None");
											}
										}
									});
									oPanel.addContent(new sap.m.Label({
										text: column,
										design: "Bold"
									}).addStyleClass("clsLabelColor"));
									oPanel.addContent(oDatePic);
								} else {
									var oInp = new sap.m.Input({
										value: value,
										width: "80%",
										enabled: false,
										maxLength: leng,
										// type: dataType,
										liveChange: function (evt) {
											if (evt.getSource().getValue().trim().length > 0) {
												evt.getSource().setValueState("None");
											}
										}
									});
									oPanel.addContent(new sap.m.Label({
										text: column,
										design: "Bold"
									}).addStyleClass("clsLabelColor"));
									oPanel.addContent(oInp);
								}

							}

							if (oData.QualDocNavi.results.length > 0) {
								var oUpload = new sap.m.Button({
									text: "Attachments",
									width: "80%",
									press: [oController.onAttachDocs, oController]
								}).addStyleClass("clsBtnColorYellowGreen");

								oPanel.addContent(new sap.m.Label({
									text: "",
									design: "Bold"
								}).addStyleClass("clsLabelColor"));
								oPanel.addContent(oUpload);
							}

							var title1 = new sap.ui.core.Title({});
							oPanel.addContent(title1);
						} else {
							// var additInfo = that.byId("newQualForm2Id");
							// additInfo.destroyContent();
							// additInfo.setVisible(false);
						}

					},
					error: function () {

					}
				});

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},

		onApprove: function () {
			var that = this;
			var oModel = that.getOwnerComponent().getModel("oDataSrv");
			var object = that.arObject;
			var payLoadObj = {};
			payLoadObj.Status = "A";
			payLoadObj.EmpId = object.EmpId;
			payLoadObj.EmpName = object.EmpName;
			payLoadObj.QualId = object.QualId;
			payLoadObj.QualDesc = object.QualDesc;
			payLoadObj.Qualification = object.Qualification;
			payLoadObj.SubDate = object.SubDate;
			payLoadObj.Timestamp = object.Timestamp;
			oModel.create("/QualAppRejDetSet", payLoadObj, {
				success: function (oData, oRes) {
					var message = JSON.parse(oRes.headers["sap-message"]).message;
					sap.m.MessageBox.success(message, {
						title: "Approved",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							that.onNavBack();
						}
					});
				},
				error: function (oErr, oResponse) {

				}
			});
		},

		onReject: function () {
			var that = this;
			var oModel = that.getOwnerComponent().getModel("oDataSrv");
			var object = that.arObject;
			var payLoadObj = {};
			payLoadObj.Status = "R";
			payLoadObj.EmpId = object.EmpId;
			payLoadObj.EmpName = object.EmpName;
			payLoadObj.QualId = object.QualId;
			payLoadObj.QualDesc = object.QualDesc;
			payLoadObj.Qualification = object.Qualification;
			payLoadObj.SubDate = object.SubDate;
			payLoadObj.Timestamp = object.Timestamp;
			oModel.create("/QualAppRejDetSet", payLoadObj, {
				success: function (oData, oRes) {
					var message = JSON.parse(oRes.headers["sap-message"]).message;
					sap.m.MessageBox.warning(message, {
						title: "Rejected",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							that.onNavBack();
						}
					});

				},
				error: function (oErr, oResponse) {

				}
			});
		},

		onAttachDocs: function (oEvent) {
			var that = this;

			if (!that._attachmentDialog) {
				that._attachmentDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.UploadDocuments", that);
				that.getView().addDependent(that._attachmentDialog);
			}
			var donloadModel = that.getView().getModel("addInfoModel");
			sap.ui.getCore().byId("downloadAttachmentsTable").setModel(donloadModel, "donloadModel");
			that._attachmentDialog.open();

		},

		onAttachCancel: function () {
			var that = this;
			that._attachmentDialog.close();
		},

		onAttachDownload: function (oEvent) {
			var that = this;
			var oPath = oEvent.getSource().getParent().getBindingContextPath();
			var oContext = oEvent.getSource().getParent().getParent().getModel("donloadModel").getProperty(oPath);
			var oDocName = oContext.DocName;
			var seqName = oContext.SeqNo;
			var oModel = that.getOwnerComponent().getModel("oDataSrv");
			oModel.read("/QualDocDownSet(EmpId='" + that.empId + "',QualId='" + that.QualId + "',DocName='" + oDocName +
				"',SeqNo='" + seqName + "',Timestamp='" + that.timeStamp + "',SubDate='" + that.subDate + "')/$value", null,
				null, false,
				function (oData, oResponse) {
					var pdfURL = oResponse.requestUri;
					var uri = pdfURL;
					that.downloadFile(uri, oDocName);
					// window.open(pdfURL);
					/*oModel.read(uri, {
						async:false,
						success: function (oDa, oRe) {
							var d = oRe.headers["content-disposition"].split(";");
							var f = d[0];
							var l = " filename=" + oDocName;
							oResponse.headers["content-disposition"] = f +";"+ l;
						}
					});*/
				},
				function (error) {
					sap.m.MessageToast.show("Failed");
				});

		},

		download: function (dataurl, Filename) {
			var downloadLink = document.createElement("a");
			downloadLink.href = dataurl;
			downloadLink.download = Filename;

			document.body.appendChild(downloadLink);
			// downloadLink.click();
			document.body.removeChild(downloadLink);
			// window.open(dataurl,"download");
		},

		downloadFile: function (uri, type) {
			var link = document.createElement("a");
			link.download = type;
			link.href = uri;
			link.click();
		}

	});

});