
/*eslint-disable sap-no-dom-access*/
/*eslint-disable sap-no-dom-insertion*/
/*eslint-disable sap-no-element-creation*/
if (!document.getElementById("polyfill_loader")) {
	var script = document.createElement("script");
	script.id = "polyfill_loader";
	script.src = "//polyfill.io/v3/polyfill.min.js";
	document.head.appendChild(script);
}
/*eslint-enable sap-no-dom-access*/
/*eslint-enable sap-no-element-creation*/
/*eslint-enable sap-no-dom-insertion*/