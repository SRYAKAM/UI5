sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel"
	], function(Controller, JSONModel) {
		"use strict";

		return Controller.extend("com.grid.controller.Grid", {
			onInit: function() {
				var that = this;
				var oModel = new JSONModel(jQuery.sap.getModulePath("com.grid", "/model/Data.json"));
				that.getView().setModel(oModel, "PlantModel");
				/*	var plantMdl = that.getView().getModel("PlantModel");
			var oPlants = [];
			for(var i=0; i<plantMdl.length; i++){
			var kval = plantMdl.getData()[i].plant;
			oPlants.push(kval);
			}
			var iValue = this.byId("mPlant");
			iValue.setValue(oPlants);*/
			},
			onSolObjReq: function() {
				var that = this;
				that._getDialog().open();
				/*	var oTable = sap.ui.getCore().byId("plantName");
			var oModel = this.getView().getModel("PlantModel").getData();*/

			},

			//----------------------------------------------------------------------------------
			//Function to Busy Dialog(Pallet)
			//----------------------------------------------------------------------------------
			_getDialog: function() {
				var that = this;
				var oView = that.getView();
				if (!that.dialog) {
					that.dialog = sap.ui.xmlfragment("com.grid.fragments.SolObjList", this);
					oView.addDependent(that.dialog);
				}
				return that.dialog;
			},
			onCancel: function() {
				var that = this;
				that._getDialog().close();
			},
			onAccept: function() {
				var oTable = sap.ui.getCore().byId("plantName");
				var aPlantitems = [];
				jQuery.each(oTable.getSelectedContextPaths(), function(id, value) {
				//	var oObj = {};
					var modelData = oTable.getModel("PlantModel");
					var data = modelData.getProperty(value);
				//	oObj.plant = data.plant;
					aPlantitems.push(data.plant);
				//	aPlantitems.push(oObj);
				});
				var iValue = this.byId("mPlant");
				var oModel1 = new JSONModel();
				oModel1.setData(aPlantitems);
				this.getView().setModel(oModel1, "oModel1");
				iValue.setValue(aPlantitems);
			
				sap.ui.getCore().byId("searchFiledId").setValue(null);
				this.dialog.close();
			},
			onReportPress: function() {
			//var mulinput = this.byId("mPlant").geValues();
			var mulinput = this.getView().getModel("oModel1").getData();
			var OArray = [];
				if (mulinput !== "") {
					if (mulinput !== undefined) {
						var oObj = {};
					//	var tokens = updateObj.Transporttype.tokens;
						var str = "";
						for (var j = 0; j < mulinput.length; j++) {
							str += mulinput[j];
							if (j !== mulinput.length - 1) {
								str += ",";
							}
								oObj.Value = str;
						}
						OArray.push(oObj);
					}
				}
			}
		});

		});