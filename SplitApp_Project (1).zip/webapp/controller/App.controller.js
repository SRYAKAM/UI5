sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/export/Spreadsheet",
	"sap/m/TablePersoController",
	"./persoservice",
	"sap/m/MessageBox"
], function(Controller, JSONModel, Filter, FilterOperator, Spreadsheet, TablePersoController, persoservice, MessageBox) {
	"use strict";

	return Controller.extend("SplitApp_Project.controller.App", {
		onInit: function() {
			var that = this;
			
			that._oTPC = new TablePersoController({
				table: that.getView().byId("datatab"),
				componentName: "Demo",
				persoService: persoservice
			}).activate();
			
			var omodel = new JSONModel({
				editable: false,
				Cancel: false,
				Region: false,
				City: false,
				Country: false,
				PaymentBlock: false
				
			});
			that.getView().setModel(omodel, "inputmodel");
			
			var PModel = new sap.ui.model.json.JSONModel();
			PModel.loadData("model/pogroup.json");
			that.getView().setModel(PModel, "poGroupModel");
			var serchModel = new JSONModel({
				pogroupval: "",
				inputValue: ""
			});
			that.getView().setModel(serchModel, "searchModel");
			var sUrl = "/sap/opu/odata/sap/ZMM_VENDORDETAIL1_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "odataModel");
			var pData = that.getView().getModel("odataModel");
			pData.read("/Vendor_headSet", {
				success: function(oData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var ProdModel = new JSONModel(oData.results);
						that.getView().setModel(ProdModel, "dataModel");
						//var data = that.getView().getModel("dataModel").getData().results;
					}
				},
				error: function(err) {
					// console.log(err);
				}
			});
		},
		OnEditClick:function(){
				var that = this;
			that.getView().getModel("inputmodel").setProperty("/editable", true);
			that.getView().getModel("inputmodel").setProperty("/Cancel",true);
			that.getView().getModel("inputmodel").setProperty("/edit", false);
			
		},
		OnCancelCick:function(){
			var that = this;
			that.getView().getModel("inputmodel").setProperty("/editable", false);
			that.getView().getModel("inputmodel").setProperty("/Cancel", false);
			that.getView().getModel("inputmodel").setProperty("/edit", true);
			
		},
		OnVisibleClick:function(){
			var that = this;
			that.getView().getModel("inputmodel").setProperty("/City", true);
			that.getView().getModel("inputmodel").setProperty("/Region", true);
			that.getView().getModel("inputmodel").setProperty("/Country", true);
			that.getView().getModel("inputmodel").setProperty("/PaymentBlock", true);
				
			
		},
		onChange:function(OEvent){
			var Range =  OEvent.getSource().getValue();
			if(Range === 1){
				MessageBox.information("selected Rating is One!");
			}else if(Range === 2) {
				MessageBox.information("Selected Rating is Two!");
				
			}else if(Range === 3){
				MessageBox.information("Selected Rating is Three!");
			}else if(Range === 4){
				MessageBox.information("Selected Rating is Four!");
				
			}else if(Range === 5){
				MessageBox.information("selected Rating is Five!");
			}else{
				MessageBox.warning("Please select any Rating!");
			}
			
		},
		onSelectionChange: function(oEvent) {
			var that = this;
			var vendor = oEvent.getSource().getSelectedItem().getBindingContext("dataModel").getObject().Lifnr;
			var sUrl = "/sap/opu/odata/sap/ZMM_VENDORDETAIL1_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "odataModel");
			var pData = that.getView().getModel("odataModel");
			pData.read("/Vendor_headSet('" + vendor + "')", {
				urlParameters: {
					"$expand": "polist_for_vendornav"
				},
				success: function(data) {
					var datamodel = new JSONModel();
					that.getView().setModel(datamodel, "datamodel");
					that.getView().getModel("datamodel").setData(data.polist_for_vendornav.results);
				}
			});
			var sObject = oEvent.getSource().getSelectedItem().getBindingContext("dataModel").getObject();
			var simpleModel = new JSONModel();
			that.getView().setModel(simpleModel, "simpleModel");
			that.getView().getModel("simpleModel").setData(sObject);
		},
		onSearch: function(oEvent) {
			var that = this;

			var filter = [];
			var SelectPoGroup = oEvent.getSource().getModel("searchModel").getProperty("/pogroupval");
			if (SelectPoGroup) {
				filter.push(new Filter("Ktokk", FilterOperator.EQ, SelectPoGroup));
			}
			var Selectinput = oEvent.getSource().getModel("searchModel").getProperty("/inputValue");
			if (Selectinput) {
				filter.push(new Filter("Lifnr", FilterOperator.EQ, Selectinput));
			}

			var oNewFilter = new Filter({
				filters: filter,
				and: true
			});
			var oTab = that.getView().byId("vendorList");
			oTab.getBinding("items").filter(oNewFilter);

		},
		onTabPerso: function(event) {
			var that = this;
			that._oTPC.openDialog();
		},
		createColumnConfig: function() {
			var aColumns = [];
			aColumns.push({
				label: "VendorNumber",
				property: "Lifnr"

			});
			aColumns.push({
				label: "PurchaseOrder",
				property: "Ebeln"
			});
			aColumns.push({
				label: "PurchaseOrganization",
				property: "Ekorg"
			});
			aColumns.push({
				label: "AvailableQuantity",
				property: "AvailQuan"
			});

			aColumns.push({
				label: "TotalQuatity",
				property: "TotalQuan"
			});
			aColumns.push({
				label: "RequestedQuntity",
				property: "ReqQuan"
			});
			aColumns.push({
				label: "Status",
				property: "Statu"
			});
			aColumns.push({
				label: "Type of Document",
				property: "Bsart"
			});
			aColumns.push({
				label: "CompanyCode",
				property: "Bukrs"
			});
			return aColumns;
		},
		onExport: function() {
			var that = this;
			var oTable = that.getView().byId("datatab");
			var tableItems = oTable.getItems();
			if (tableItems.length > 0) {
				//varibles related to spreedsheet
				var aColumns, oSettings, oSheet;
				aColumns = that.createColumnConfig();
				var collectionRecord = that.getView().getModel("datamodel").getData();
				//calling columns event in order to get that colums
				// aCols = that.createColumnConfig();
				//geting whole data from model
				oSettings = {
					workbook: {
						columns: aColumns,
						context: {
							sheetName: "Vendor list"
						}
					},
					dataSource: collectionRecord,
					fileName: "Vendor list"
				};
				//created spreedsheet
				oSheet = new sap.ui.export.Spreadsheet(oSettings);
				oSheet.build()
					.then(function() {
						//    MessageToast.show("Spreadsheet export has finished);
					})
					.finally(function() {
						oSheet.destroy();
					});
			}

		},
		onSearchany: function(oEvent) {
			var tableId = this.byId("datatab");
			var inputValue = oEvent.getParameter("query");
			var trimValue = inputValue.trim();
			var filterArr = [];
			var dateArr = [];
			var items = tableId.getBinding("items");
			var filter1 = new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter2 = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter3 = new sap.ui.model.Filter("Ekorg", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter4 = new sap.ui.model.Filter("AvailQuan", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter5 = new sap.ui.model.Filter("TotalQuan", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter6 = new sap.ui.model.Filter("ReqQuan", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter7 = new sap.ui.model.Filter("Statu", sap.ui.model.FilterOperator.EQ, trimValue);
			var filter8 = new sap.ui.model.Filter("Bsart", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter9 = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Containms, trimValue);
			filterArr = [filter1, filter2, filter3, filter4, filter5, filter6, filter7, filter8];
			dateArr = [filter9];
			var finalFilter = new sap.ui.model.Filter({
				filters: filterArr,
				filters1: dateArr,
				and: false
			});
			items.filter(finalFilter);
		},
		ListSearch: function(oEvent) {
			var listsearch = oEvent.getSource().getValue();
			var listdata = this.getView().byId("vendorList").getBinding("items");
			var listFilter1 = new sap.ui.model.Filter("Lifnr", FilterOperator.EQ, listsearch);
			var listFilter2 = new sap.ui.model.Filter("Name", FilterOperator.Contains, listsearch);
			var listFilter3 = new sap.ui.model.Filter("Ktokk", FilterOperator.Contains, listsearch);
			var filter = [listFilter1, listFilter2, listFilter3];
			var filters = new sap.ui.model.Filter(filter, false);
			listdata.filter(filters);
		},
		oNRequestClick: function() {

			var that = this;
			var oArray = [];
			var selectedindex = that.getView().byId("datatab");
			var selecteditem = selectedindex.getSelectedContexts();
			if (selecteditem.length === 0) {
				MessageBox.warning("Please select at least one Record for Request for Change");
			} else {
				selecteditem.forEach(function(item) {
					var object = item.getObject();
					oArray.push(object);
					that.reqQuantity = parseInt(object.ReqQuan);
					if (that.reqQuantity > 0) {
						if (that.reqQuantity < parseInt(object.AvailQuan) || that.reqQuantity === parseInt(object.AvailQuan)) {
							that.formdata = {};
							var data = that.getView().getModel("simpleModel");
							that.formdata = data.getData();
							data.setProperty("/polist_for_vendornav", oArray);
						} else {
							sap.m.MessageBox.warning("Required Quantity must be lessthan or equal to avaliable quantity");
						}
					} else {
						sap.m.MessageBox.warning("value Must be greater 0 to update");
					}
				});

				var sUrl = "/sap/opu/odata/sap/ZMM_VENDORDETAIL1_SRV/";
				var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
				that.getView().setModel(oModel, "odataModel");
				var pData = that.getView().getModel("odataModel");
				pData.create("/Vendor_headSet", that.formdata, {
					success: function(data, res) {
						pData.read("/Vendor_headSet('" + that.formdata.Lifnr + "')", {
							urlParameters: {
								"$expand": "polist_for_vendornav"
							},
							success: function(OData, resource) {
								if (resource.statusCode === "200" || resource.statusCode === 200) {
									sap.m.MessageBox.success("Updated for quantity Successfully!");
									that.getView().getModel("datamodel").setData(OData.polist_for_vendornav.results);

								}
							},
							error: function(error) {

							}
						});
					}
				});
			}

		},
		onUpdateFinished: function(oEvent) {
			var that = this;
			var defaultselect = that.getView().byId("vendorList");
			var olist = defaultselect.getItems()[0];
			defaultselect.setSelectedItem(olist, true);
			oEvent.getSource().fireSelectionChange({
				listItem: defaultselect.getSelectedItem()
			});
		},
		validateinput: function(OEvent) {
			var validate = OEvent.getSource().getValue();
			if (validate >= 100) {
				OEvent.getSource().setValue(validate.slice(0, 3));
				sap.m.MessageToast.show("value not greaterthan 100");
			}
		}

	});
});