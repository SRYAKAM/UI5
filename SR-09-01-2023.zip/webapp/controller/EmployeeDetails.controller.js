sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History"
	
], function(Controller, JSONModel, Filter, FilterOperator, History) {
	"use strict";

	return Controller.extend("com.SRSR-09-01-2023.controller.EmployeeDetails", {
		onInit: function() {
			var that = this;
			var oRouter = that.getOwnerComponent().getRouter();
			oRouter.getRoute("view2").attachPatternMatched(that.onObjectMatched, that);
		},
		onObjectMatched: function(oEvent) {
			var that = this;
			var mFilters = [];
			var selectedArguments = oEvent.getParameter("arguments").Details;
			var dataModel = that.getOwnerComponent().getModel("employeeModel");
				// mFilters.push(new Filter("EmpId", FilterOperator.EQ, selectedArguments));
			dataModel.read("/Employee_DetailsSet('" + selectedArguments + "')", {
				filters: mFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "employeeData");
					}
				},
				error: function(err) {

				}
			});
		},
		onBack: function() {

			var oHistory, sPreviousHash;

			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("InitialView", {}, true /*no history*/ );
			}
		}
	});
});