sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/export/Spreadsheet",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/m/MessageBox",
	"sap/m/TablePersoController",
	"./persoservice",
	"sap/ui/core/ValueState"

], function(Controller, JSONModel, Filter, FilterOperator, Spreadsheet, Export, ExportTypeCSV, MessageBox, TablePersoController,
	persoservice, ValueState) {
	"use strict";
	return Controller.extend("siva-09-01-2022.controller.App", {
		onInit: function(OEvent) {
			var that = this;
			that._oTPC = new TablePersoController({
				table: that.getView().byId("datatab"),
				componentName: "Demo",
				persoService: persoservice
			}).activate();
			var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
		
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
				oModel.setUseBatch(true);
			that.getView().setModel(oModel, "odataModel");
			var pData = that.getView().getModel("odataModel");
			pData.read("/Employee_DetailsSet", {
				success: function(oData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var ProdModel = new JSONModel(oData.results);
						that.getView().setModel(ProdModel, "dataModel");
						//var data = that.getView().getModel("dataModel").getData().results;
					}
				},
				error: function(err) {
					// console.log(err);
				}
			});

			var PModel = new JSONModel({
				"empId": "",
				"empName": "",
				"empDesignation": "",
				"empLocaton": "",
				"empDept": "",
				"DOJ": ""

			});
			that.getView().setModel(PModel, "dummyModel");
			that.OnDesignation();
			that.onLocation();
			that.departmentdata();

			var modelcreate = new JSONModel({
				"Firstname": "",
				"Secondname": "",
				"Designation": "",
				"Location": "",
				"Department": "",
				"Reportto": "",
				"Experience": "",
				"Joiningdate": "",
				"Dob": "",
				"Street": "",
				"Village": "",
				"Landmark": "",
				"Mandal": "",
				"District": "",
				"Pincode": "",
				"State": "",
				"Phonenumber": "",
				"Op2022": "",
				"Op2021": "",
				"Op2020": ""
			});
			that.getView().setModel(modelcreate, "createmodel");

			var inputModel = new JSONModel({
				"Op2022": false,
				"Op2021": false,
				"Op2020": false
			});
			that.getView().setModel(inputModel, "yearVisibility");

		},
		getservicedata: function() {
			var that = this;
			var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "odataModel");
			var pData = that.getView().getModel("odataModel");
			pData.read("/Employee_DetailsSet", {
				success: function(oData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var ProdModel = new JSONModel(oData.results);
						that.getView().setModel(ProdModel, "dataModel");
						//var data = that.getView().getModel("dataModel").getData().results;
					}
				},
				error: function(err) {
					// console.log(err);
				}
			});
		},

		OnDesignation: function(oEvent) {
			var that = this;
			var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "odataModel");
			var pData = that.getView().getModel("odataModel");
			var DFilters = [];
			DFilters.push(new Filter("Flag", FilterOperator.EQ, "D"));
			pData.read("/EmployeeSearchHelpSet", {
				filters: DFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeemodel = new JSONModel(OData.results);
						that.getView().setModel(employeemodel, "desmodel");

					}
				},
				error: function(err) {

				}
			});

		},
		onLocation: function(oEvent) {
			var that = this;
			var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "odataModel");
			var pData = that.getView().getModel("odataModel");
			var DFilters = [];
			DFilters.push(new Filter("Flag", FilterOperator.EQ, "L"));
			pData.read("/EmployeeSearchHelpSet", {
				filters: DFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeemodel = new JSONModel(OData.results);
						that.getView().setModel(employeemodel, "Locmodel");

					}
				},
				error: function(err) {

				}
			});

		},
		departmentdata: function() {
			var that = this;
			var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "odataModel");
			var pData = that.getView().getModel("odataModel");
			var DFilters = [];
			DFilters.push(new Filter("Flag", FilterOperator.EQ, "DP"));
			pData.read("/EmployeeSearchHelpSet", {
				filters: DFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeemodel = new JSONModel(OData.results);
						that.getView().setModel(employeemodel, "depmodel");

					}
				},
				error: function(err) {

				}
			});
		},
		deptdialogboxopen: function() {
			var that = this;
			if (!that.listDialog) {
				that.listDialog = sap.ui.xmlfragment("siva-09-01-2022.fragments.Department", that.getView()
					.getController());
				that.getView().addDependent(that.listDialog);
			}
			that.listDialog.open();
		},
		onlistPressCancel: function() {
			var that = this;
			that.listDialog.close();
		},
		getSearchfilters: function(query) {
			return new Filter({
				filters: [new Filter("EmpId", FilterOperator.Contains, query),
					new Filter("Firstname", FilterOperator.Contains, query),
					new Filter("Designation", FilterOperator.Contains, query),
					new Filter("Location", FilterOperator.Contains, query),
					new Filter("Department", FilterOperator.Contains, query),
					new Filter("Reportto", FilterOperator.Contains, query),
					new Filter("Experience", FilterOperator.Contains, query),
					new Filter("Joiningdate", FilterOperator.Contains, query)
				],
				and: false
			});
		},
		onSearch: function(oEvent) {
			var tableId = this.byId("datatab");
			var inputValue = oEvent.getParameter("query");
			var trimValue = inputValue.trim();
			var filterArr = [];
			var dateArr = [];
			var items = tableId.getBinding("items");
			var filter1 = new sap.ui.model.Filter("EmpId", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter2 = new sap.ui.model.Filter("Firstname", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter3 = new sap.ui.model.Filter("Designation", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter4 = new sap.ui.model.Filter("Location", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter5 = new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter6 = new sap.ui.model.Filter("Reportto", sap.ui.model.FilterOperator.Contains, trimValue);
			var filter7 = new sap.ui.model.Filter("Experience", sap.ui.model.FilterOperator.EQ, trimValue);
			var filter8 = new sap.ui.model.Filter("Joiningdate", sap.ui.model.FilterOperator.Contains, trimValue);
			filterArr = [filter1, filter2, filter3, filter4, filter5, filter6, filter7];
			dateArr = [filter8];
			var finalFilter = new sap.ui.model.Filter({
				filters: filterArr,
				filters1: dateArr,
				and: false
			});
			items.filter(finalFilter);

			// var that = this;

			// var query = oEvent.getParameter("sQuery");

			// var contains = sap.ui.model.FilterOperator.Contains;
			// var oFilters = new sap.ui.model.Filter([
			// 	new sap.ui.model.Filter("EmpId", contains, query),
			// 	new sap.ui.model.Filter("Firstname", contains, query),
			// 	new sap.ui.model.Filter("Designation", contains, query),
			// 	new sap.ui.model.Filter("Location", contains, query),
			// 	new sap.ui.model.Filter("Department", contains, query),
			// 	new sap.ui.model.Filter("Reportto", contains, query),
			// 	new sap.ui.model.Filter("Experience", contains, query),
			// 	new sap.ui.model.Filter("Joiningdate", contains, query)
			// ], false);
			// that.getView().byId("datatab").getBinding("items").filter(oFilters);
			// 			var query = oEvent.getParameter("newValue");
			// 			 if (query && query.length > 0) {
			// 			var filters = [new Filter("EmpId", FilterOperator.Contains, query),
			// 				new Filter("Firstname", FilterOperator.Contains, query),
			// 				new Filter("Designation", FilterOperator.Contains, query),
			// 				new Filter("Location", FilterOperator.Contains, query),
			// 				new Filter("Department", FilterOperator.Contains, query),
			// 				new Filter("Reportto", FilterOperator.Contains, query),
			// 				new Filter("Experience", FilterOperator.Contains, query),
			// 				new Filter("Joiningdate", FilterOperator.Contains, query)
			// 			];
			// 			var oFilter = new Filter(filters, false); //False means it will apply an OR logic, if you want AND pass true
			// 			//Get binding of component and apply it, let's suppose it's a List
			// 			that.getView().byId("datatab").getBinding("items").filter(oFilter);
			// }
		},
		createColumnConfig: function() {
			var aColumns = [];
			aColumns.push({
				label: "EmpId",
				property: "EmpId"

			});
			aColumns.push({
				label: "Firstname",
				property: "Firstname"
			});
			aColumns.push({
				label: "Designation",
				property: "Designation"
			});
			aColumns.push({
				label: "Location",
				property: "Location"
			});

			aColumns.push({
				label: "Department",
				property: "Department"
			});
			aColumns.push({
				label: "Reportto",
				property: "Reportto"
			});
			aColumns.push({
				label: "Experience",
				property: "Experience"
			});
			aColumns.push({
				label: "Joiningdate",
				property: "Joiningdate"
			});
			return aColumns;
		},
		onExport: function() {
			var that = this;
			var oTable = that.getView().byId("datatab");
			var tableItems = oTable.getItems();
			if (tableItems.length > 0) {
				//varibles related to spreedsheet
				var aColumns, oSettings, oSheet;
				aColumns = that.createColumnConfig();
				var collectionRecord = that.getView().getModel("dataModel").getData();
				//calling columns event in order to get that colums
				// aCols = that.createColumnConfig();
				//geting whole data from model
				oSettings = {
					workbook: {
						columns: aColumns,
						context: {
							sheetName: "Employee list"
						}
					},
					dataSource: collectionRecord,
					fileName: "Employee list"
				};
				//created spreedsheet
				oSheet = new sap.ui.export.Spreadsheet(oSettings);
				oSheet.build()
					.then(function() {
						//    MessageToast.show("Spreadsheet export has finished);
					})
					.finally(function() {
						oSheet.destroy();
					});
			}

		},
		oncsvdown: function() {
			var oExport = new Export({
				exportType: new ExportTypeCSV({
					separatorChar: ";"
				}),
				models: this.getView().getModel("dataModel"),
				rows: {
					path: "/Employee_DetailsSet"
				},
				columns: [{
					name: "EmpId",
					template: {
						content: "{EmpId}"
					}
				}, {
					name: "Firstname",
					template: {
						content: "{Firstname}"
					}
				}, {
					name: "Designation",
					template: {
						content: "{Designation}"
					}
				}, {
					name: "Location",
					template: {
						content: "{Location}"
					}
				}, {
					name: "Department",
					template: {
						content: "{Department}"
					}
				}, {
					name: "Reportto",
					template: {
						content: "{Reportto}"
					}
				}, {
					name: "Experience",
					template: {
						content: "{Experience}"
					}
				}, {
					name: "Experience",
					template: {
						content: "{Experience}"
					}
				}]
			});
			// download exported file
			oExport.saveFile().catch(function(oError) {
				// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
			}).then(function() {
				oExport.destroy();
			});
		},
		onPressDelete: function(oEvent) {
			var that = this;
			var selectedIndex = that.getView().byId("datatab").getSelectedContexts()[0];
			if (selectedIndex !== undefined) {
				var selectedrow = selectedIndex.getObject().EmpId;
				var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
				var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
				that.getView().setModel(oModel, "odataModel");
				var pData = that.getView().getModel("odataModel");
				pData.remove("/Employee_DetailsSet('" + selectedrow + "')", {
					success: function(oData) {
						MessageBox.show("Deleted Successfully");
						that.getservicedata();
					}
				});
			} else {
				MessageBox.warning("please select a row ");
			}
		},
		onTabPerso: function(event) {
			var that = this;
			that._oTPC.openDialog();
		},
		onPressAdd: function() {
			var that = this;
			if (!that.addDialog) {
				that.addDialog = sap.ui.xmlfragment("siva-09-01-2022.fragments.employeeForm", that.getView()
					.getController());
				that.getView().addDependent(that.addDialog);
			}
			that.addDialog.open();
		},
		// onPressAdd: function() {
		// 	var that = this;
		// 	if (!that.oDialog) {
		// 		that.oDialog = sap.ui.xmlfragment("siva-09-01-2022.fragments.employeeForm", that);
		// 		that.getView().addDependent(that.oDialog);
		// 	}
		// 	that.oDialog.open();
		// },
		onPressCancel: function() {
			var that = this;
			that.addDialog.close();
			that.addDialog.destroy();
			that.addDialog = null;
		},
		onCancelPress: function() {
			var that = this;
			that.listDialog.close();
			that.listDialog.destroy();
			that.listDialog = null;
		},
		Onsearchbuttonclick: function(oEvent) {
			var that = this;
			var filter = [];
			var SelectEmpname = oEvent.getSource().getModel("dummyModel").getProperty("/empName");
			if (SelectEmpname) {
				filter.push(new Filter("Firstname", FilterOperator.Contains, SelectEmpname));
			}
			var selectedDesignation = oEvent.getSource().getModel("dummyModel").getProperty("/empDesignation");
			if (selectedDesignation) {
				filter.push(new Filter("Designation", FilterOperator.Contains, selectedDesignation));
			}
			var selectedLocation = oEvent.getSource().getModel("dummyModel").getProperty("/empLocaton");
			if (selectedLocation) {
				filter.push(new Filter("Location", FilterOperator.Contains, selectedLocation));
			}
			var selectedDept = oEvent.getSource().getModel("dummyModel").getProperty("/empDept");
			if (selectedDept) {
				filter.push(new Filter("Department", FilterOperator.Contains, selectedDept));
			}
			var selectedDOJ = oEvent.getSource().getModel("dummyModel").getProperty("/DOJ");
			if (selectedDOJ) {
				filter.push(new Filter("DOJ", FilterOperator.Contains, selectedDOJ));
			}

			var oNewFilter = new Filter({
				filters: filter,
				and: false
			});
			var oTab = that.getView().byId("datatab");
			oTab.getBinding("items").filter(oNewFilter);
		},
		OnRefresh: function() {
			var that = this;
			var oTable = that.getView().byId("datatab");
			var oBinding = oTable.getBinding("items");
			oBinding.sort(null);
			oBinding.filter(null);
			that.getView().getModel("dummyModel").setProperty("/empName", null);
			that.getView().getModel("dummyModel").setProperty("/empDesignation", null);
			that.getView().getModel("dummyModel").setProperty("/empLocaton", null);
			that.getView().getModel("dummyModel").setProperty("/empDept", null);
			that.getView().getModel("dummyModel").setProperty("/DOJ", null);

		},
		handleChange: function() {
			var that = this;
			that.getView().getModel("dummymodel").getProperty("/DOJ");
		},
		onpress: function(oEvent) {
			var oItem = oEvent.getSource();
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("App1", {
				Product: oItem.getBindingContext("dataModel").getObject().EmpId

			});
		},
		OnpressCreate: function() {
			var that = this;
			var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "odataModel");
			var pData = that.getView().getModel("odataModel");
			var EmpData = that.getView().getModel("createmodel").getData();
			var firstName = EmpData.Firstname;
			var lastName = EmpData.Secondname;
			if (firstName !== "" && lastName !== "") {
				pData.create("/Employee_DetailsSet", EmpData, {
					success: function(OData) {
						that.addDialog.close();
						that.addDialog.destroy();
						that.addDialog = null;
						that.getservicedata();
						MessageBox.show("Record Created Successfuly");

					}

				});

			} else {
				MessageBox.warning("Please enter Details to Create a record");
			}

		},
		onpressdepartmentlist: function(OControlEvent) {
			var that = this;
			var departmentitem = OControlEvent.getParameters("listItems").selectedContexts[0].getObject().Description;
			that.getView().getModel("dummyModel").setProperty("/empDept", departmentitem);
			that.getView().getModel("createmodel").setProperty("/Department", departmentitem);
		},
		ValidateInput: function(oEvent) {
			var that = this;
			var Visdate = oEvent.getSource().getName();
			var VisYear = oEvent.getSource().getValue().slice(0, 4);
			if (Visdate === "joiningDate") {
				if (VisYear === "2022") {
					that.getView().getModel("yearVisibility").setProperty("/Op2022", true);
					that.getView().getModel("yearVisibility").setProperty("/Op2021", false);
					that.getView().getModel("yearVisibility").setProperty("/Op2020", false);
				} else if (VisYear === "2021") {
					that.getView().getModel("yearVisibility").setProperty("/Op2022", false);
					that.getView().getModel("yearVisibility").setProperty("/Op2021", true);
					that.getView().getModel("yearVisibility").setProperty("/Op2020", false);
				} else if (VisYear === "2020") {
					that.getView().getModel("yearVisibility").setProperty("/Op2022", false);
					that.getView().getModel("yearVisibility").setProperty("/Op2021", false);
					that.getView().getModel("yearVisibility").setProperty("/Op2020", true);
				} else {
					MessageBox.error("Please check the year, year should be on between 2020 to 2022");
				}
			}
		},
		statusColor: function(Sval) {
			
			// var that = this;
			// var oTable = that.getView().byId("datatab");
	    	
			// var rowCount = oTable.getVisibleRowCount();
			// var rowStart = oTable.getFirstVisibleRow();
			// var currentRowContext;
			// for (var i = 0; i < rowCount; i++) 
			// 	currentRowContext = oTable.getContextByIndex(rowStart + i);
			// 	// Remove Style class else it will overwrite
   //             oTable.getRows()[i].$().removeClass("yellow");
   //             oTable.getRows()[i].$().removeClass("green");
   //             oTable.getRows()[i].$().removeClass("red");
   //             var cellValue = that.getView().getModel("dataModel").getProperty("Reportto", currentRowContext);
   //             if (cellValue === "Venkatesh") {
   //                 oTable.getRows()[i].$().addClass("green");
   //             }  else {
   //                 oTable.getRows()[i].$().addClass("red");
   //             }

				if (Sval === "Venkatesh") {
					// this.getView().byId("datatab").addStyleClass(".yellow"); 
					// return "Blue";
				this.getView().byId("datatab").addStyleClass("red");
				return Sval;
				} else{
			        this.getView().byId("datatab").addStyleClass("green"); 
				}
				 return Sval;
		}

	});
});