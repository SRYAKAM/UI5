sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"

], function(Controller, JSONModel, MessageBox) {
	"use strict";
	return Controller.extend("siva-09-01-2022.controller.App1", {
		onInit: function() {
			var that = this;
			var omodel = new JSONModel({
				editable: false,
				save: false,
				cancel: false

			});
			that.getView().setModel(omodel, "inputmodel");

			var oRouter = that.getOwnerComponent().getRouter();
			oRouter.getRoute("App1").attachPatternMatched(that._onObjectMatched, that);
		},
		_onObjectMatched: function(oEvent) {
			var that = this;
			var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "odataModel");
			var pData = that.getView().getModel("odataModel");
			var prodval = oEvent.getParameter("arguments").Product;
			pData.read("/Employee_DetailsSet('" + prodval + "')", {
				success: function(oData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var ProdModel = new JSONModel(oData);
						that.getView().setModel(ProdModel, "formdatamodel");
						//var data = that.getView().getModel("dataModel").getData().results;

					}
				},
				error: function(err) {
					// console.log(err);
				}
			});
		},
		performance: function(oEvent) {
			var getNamePerf = oEvent.getSource().getText();
			if (getNamePerf === "Performance") {
				sap.ui.MessageBox.Show();

			}
		},
		onNavBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("App");
		},
		onEditPress: function() {
			var that = this;
			that.getView().getModel("inputmodel").setProperty("/editable", true);
			that.getView().getModel("inputmodel").setProperty("/save", true);
			that.getView().getModel("inputmodel").setProperty("/cancel", true);
			that.getView().getModel("inputmodel").setProperty("/edit", false);

		},
		onSavePress: function() {
			var that = this;
			that.getView().getModel("inputmodel").setProperty("/editable", false);
			that.getView().getModel("inputmodel").setProperty("/save", false);
			that.getView().getModel("inputmodel").setProperty("/cancel", false);
			that.getView().getModel("inputmodel").setProperty("/edit", true);
			var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "odataModel");
			var UData = that.getView().getModel("odataModel");
			var selecteddata = that.getView().getModel("formdatamodel").getData();
			UData.update("/Employee_DetailsSet('" + selecteddata.EmpId + "')", selecteddata, {
				success: function(oData, res) {
					MessageBox.show("Update Successfully");
				}

			});

		},
		onCancelPress: function() {
			var that = this;
			that.getView().getModel("inputmodel").setProperty("/editable", false);
			that.getView().getModel("inputmodel").setProperty("/save", false);
			that.getView().getModel("inputmodel").setProperty("/cancel", false);
			that.getView().getModel("inputmodel").setProperty("/edit", true);
		}

	});
});